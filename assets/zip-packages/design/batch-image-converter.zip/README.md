# Batch Image Resizer & Format Converter

A free, browser-based image resizing and format conversion tool. Process multiple images at once — no installation required.

---

## Features

- 🖼️ **Batch Processing** — Resize and convert multiple images at once
- 📐 **Preset Sizes** — Amazon, Instagram, Facebook, Twitter, and custom sizes
- 🔄 **Format Conversion** — Convert between JPG, PNG, WebP, and BMP
- 🎚️ **Quality Control** — Adjust output quality from 10% to 100%
- 👁️ **Image Preview** — Preview images before processing
- 📥 **Auto Download** — Download all processed images automatically
- 🔒 **100% Private** — All processing happens locally; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works completely offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Upload Images

Click the upload area or drag and drop images. Supports JPG, PNG, GIF, WebP, BMP, and SVG.

### Step 3: Choose Settings

| Setting | Description |
|---------|-------------|
| **Preset Size** | Choose from common social media and platform sizes |
| **Output Format** | Select JPG, PNG, WebP, or BMP |
| **Quality** | Adjust from 10% (smaller file) to 100% (best quality) |

### Step 4: Process & Download

Click **Process & Download All**. Each image will be resized and downloaded automatically.

---

## Preset Sizes

| Preset | Dimensions | Use Case |
|--------|-----------|----------|
| Amazon Product | 800×800 | Amazon product listings |
| Facebook Share | 1200×628 | Facebook link shares |
| Instagram Post | 1080×1080 | Square Instagram posts |
| Instagram Story | 1080×1920 | Full-screen stories |
| Twitter Header | 1500×500 | Twitter profile headers |
| Open Graph | 1200×630 | Social media previews |
| 2K Monitor | 2560×1440 | 2K displays |
| Full HD | 1920×1080 | Standard HD displays |
| 4K Ultra HD | 3840×2160 | 4K displays |

---

## Output Formats

| Format | Best For | Transparency | Compression |
|--------|----------|-------------|-------------|
| **JPG** | Photos, gradients | No | Lossy (adjustable) |
| **PNG** | Logos, screenshots | Yes | Lossless |
| **WebP** | Modern web | Yes | Lossy/Lossless |
| **BMP** | Uncompressed | Yes | None |

---

## Use Cases

- **E-commerce Sellers** — Resize product photos for Amazon, eBay, Shopify
- **Social Media Managers** — Prepare images for different platforms
- **Photographers** — Batch resize portfolios for web delivery
- **Web Developers** — Optimize images for faster page loading

---

## File Structure

```
image-converter/
├── index.html      # Main tool file