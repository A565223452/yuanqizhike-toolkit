# Color Code Converter

A free, browser-based color converter tool. Instantly convert between HEX, RGB, and HSL color formats — no installation required.

---

## Features

- 🎨 **HEX ↔ RGB ↔ HSL** — Convert between three major color formats simultaneously
- 🖱️ **Visual Color Picker** — Select colors visually using the built-in color picker
- ⌨️ **Manual HEX Input** — Type a HEX code directly to see RGB and HSL values
- 🎭 **Palette Generator** — Auto-generate analogous, complementary, triadic, and split-complementary palettes
- ♿ **WCAG Contrast Checker** — Verify color contrast ratios for accessibility compliance
- 📋 **One-Click Copy** — Copy individual values or all color codes
- 💾 **Export CSS Variables** — Export palettes as CSS custom properties
- 🔒 **100% Private** — All processing happens locally; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works completely offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Choose a Color

You have two options:

**Option A — Visual Picker:**
Click the color picker box on the left to open your system's color picker dialog. Select any color you like.

**Option B — Manual HEX Input:**
Type a HEX color code (e.g., `#FF5733`) into the text input field on the right.

### Step 3: View Converted Values

The tool automatically displays the equivalent values in all three formats:

| Format | Description | Example |
|--------|-------------|---------|
| **HEX** | Hexadecimal color code | `#3498db` |
| **RGB** | Red, Green, Blue (0-255) | `rgb(52, 152, 219)` |
| **HSL** | Hue, Saturation, Lightness | `hsl(204, 70%, 53%)` |

### Step 4: Copy All Codes

Click the **Copy All Codes** button to copy all three color values to your clipboard in the following format:

```
HEX:#3498db
RGB:rgb(52,152,219)
HSL:hsl(204,70%,53%)
```

---

## Palette Generation

Switch to the **Palette** tab to generate color harmonies based on your selected color:

| Palette Type | Description |
|--------------|-------------|
| **Analogous** | Colors adjacent on the color wheel (±30°) |
| **Complementary** | Opposite color on the wheel (180°) |
| **Triadic** | Three colors evenly spaced (120° apart) |
| **Split Complementary** | Two colors adjacent to the complement |
| **Tints** | Lighter and darker variants |

Click any swatch to copy its color code.

---

## Accessibility — WCAG Contrast Checker

Switch to the **Accessibility** tab to check color contrast ratios:

| Standard | Ratio Required | Use Case |
|----------|---------------|----------|
| **AA Normal** | ≥ 4.5:1 | Regular text |
| **AA Large** | ≥ 3:1 | Large text (18pt+) |
| **AAA Normal** | ≥ 7:1 | Enhanced accessibility |
| **AAA Large** | ≥ 4.5:1 | Enhanced large text |

The checker provides live preview and pass/fail indicators for each standard.

---

## Common Color Codes Reference

### Basic Colors

| Color | HEX | RGB | HSL |
|-------|-----|-----|-----|
| Red | `#FF0000` | `rgb(255,0,0)` | `hsl(0,100%,50%)` |
| Green | `#00FF00` | `rgb(0,255,0)` | `hsl(120,100%,50%)` |
| Blue | `#0000FF` | `rgb(0,0,255)` | `hsl(240,100%,50%)` |
| White | `#FFFFFF` | `rgb(255,255,255)` | `hsl(0,0%,100%)` |
| Black | `#000000` | `rgb(0,0,0)` | `hsl(0,0%,0%)` |

### Popular Web Colors

| Color | HEX | RGB | HSL |
|-------|-----|-----|-----|
| Royal Blue | `#3498DB` | `rgb(52,152,219)` | `hsl(204,70%,53%)` |
| Emerald | `#2ECC71` | `rgb(46,204,113)` | `hsl(146,63%,50%)` |
| Sunflower | `#F1C40F` | `rgb(241,196,15)` | `hsl(48,89%,50%)` |
| Coral | `#E74C3C` | `rgb(231,76,60)` | `hsl(6,78%,57%)` |
| Purple | `#9B59B6` | `rgb(155,89,182)` | `hsl(283,39%,53%)` |

---

## Understanding Color Formats

### HEX (Hexadecimal)

- Format: `#RRGGBB` where RR, GG, BB are hex values (00-FF)
- Range: `#000000` (black) to `#FFFFFF` (white)
- Widely used in CSS, HTML, and design tools
- Short form: `#FFF` is equivalent to `#FFFFFF`

### RGB (Red, Green, Blue)

- Format: `rgb(red, green, blue)` where each value ranges from 0 to 255
- Additive color model — combining all at maximum creates white
- Used in screens, cameras, and digital displays

### HSL (Hue, Saturation, Lightness)

- Format: `hsl(hue, saturation%, lightness%)`
- **Hue**: 0°–360° angle on the color wheel (0=red, 120=green, 240=blue)
- **Saturation**: 0% (gray) to 100% (full color)
- **Lightness**: 0% (black) to 100% (white), 50% is normal
- Intuitive for humans to pick and adjust colors

---

## File Structure

```
color-converter/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `<input type="color">`
- `navigator.clipboard.writeText()`
- ES6 template literals

Recommended: Chrome 50+, Firefox 49+, Edge 14+, Safari 10+

---

## Use Cases

- **Web Developers** — Quickly convert colors between formats for CSS
- **UI/UX Designers** — Find exact RGB/HSL values from a HEX code
- **Frontend Developers** — Debug color issues in responsive designs
- **Content Creators** — Maintain consistent brand colors across platforms

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**