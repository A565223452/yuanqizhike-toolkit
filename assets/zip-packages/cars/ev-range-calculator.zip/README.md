# EV Range Calculator

A free, browser-based electric vehicle range calculator. Estimate real-world driving range based on battery capacity, efficiency, driving style, temperature, and climate control — no installation required.

---

## Features

- Real-world range estimation with environmental factors
- Vehicle presets (Tesla Model 3/Y, Nissan Leaf, Chevy Bolt, VW ID.4, Kia EV6, Ford Mach-E)
- Driving style and speed impact analysis
- Temperature and HVAC (heater/AC) adjustment
- Speed-based range estimation table (30–80 mph)
- Supports miles and kilometers

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

1. Pick a vehicle preset or enter custom battery capacity and efficiency.
2. Adjust driving style, temperature, and climate control usage.
3. Click **Calculate** to see estimated real-world range.
4. Review the speed-based range table for highway vs. city planning.

All processing happens locally in your browser.

---

## Use Cases

- **EV shoppers** comparing real-world range across models
- **EV owners** planning road trips with HVAC and temperature in mind
- **Fleet managers** estimating daily range for delivery routes
- **Curious drivers** learning how speed and weather affect range

---

## File Structure

```
ev-range-calculator/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- ES6+ JavaScript features
- CSS Grid / Flexbox

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Auto & Vehicles Tools**
