# Oil Change Interval Calculator

A free, browser-based oil change interval calculator. Determine the optimal oil change schedule based on mileage, oil type, driving conditions, and vehicle age — no installation required.

---

## Features

- Next oil change mileage and date estimation
- Oil type comparison (conventional, synthetic blend, full synthetic, high mileage)
- Normal vs. severe driving condition adjustment
- 5-service future maintenance plan table
- Oil type comparison table with annual cost estimate
- Overdue warnings and progress tracking
- Supports miles and kilometers

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

1. Enter your **current mileage** and **last oil change mileage**.
2. Select **oil type** (conventional, synthetic blend, full synthetic, high mileage).
3. Choose **driving conditions** (normal or severe).
4. Enter **annual mileage** and **vehicle age**.
5. Click **Calculate** for your personalized oil change schedule.

All processing happens locally in your browser.

---

## Use Cases

- **Car owners** tracking when to schedule the next oil change
- **DIY mechanics** planning maintenance intervals by oil type
- **Fleet managers** standardizing service schedules across vehicles
- **Used car buyers** verifying maintenance history timing

---

## File Structure

```
oil-change-interval/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- ES6+ JavaScript features
- CSS Grid / Flexbox

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Auto & Vehicles Tools**
