# Article Rewriter & Similarity Checker

A free, browser-based content rewriting and similarity checking tool. Rewrite articles and check content similarity — no installation required.

---

## Features

- ✍️ **AI-Powered Content Rewriting** — Rewrite text using synonym substitution
- 📊 **Similarity Checker** — Calculate content similarity percentage
- 📚 **Built-in Synonym Dictionary** — Over 100 word synonyms included
- 📋 **One-Click Copy** — Copy rewritten content instantly
- 🔒 **100% Private** — All processing happens locally; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works completely offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Enter Your Content

Paste or type your original content into the text area at the top.

### Step 3: Rewrite Content

Click the **Rewrite Content** button. The tool will automatically substitute words with synonyms from the built-in dictionary.

### Step 4: Check Similarity

Click the **Check Similarity** button to calculate how similar the rewritten content is to the original.

### Step 5: Copy Result

Click the **Copy Result** button to copy the rewritten text to your clipboard.

---

## Synonym Dictionary

The tool includes a built-in synonym dictionary with over 100 words. The dictionary is expandable — engineers can add more synonyms to improve rewriting quality.

### Sample Entries

| Word | Synonyms |
|------|----------|
| good | excellent, great, outstanding, superb, fine |
| bad | poor, terrible, awful, dreadful, inferior |
| use | utilize, employ, make use of, apply, leverage |
| help | assist, aid, support, facilitate, enable |
| important | crucial, essential, vital, significant, critical |

---

## Use Cases

- **Content Writers** — Rewrite existing content to avoid plagiarism
- **SEO Specialists** — Create unique variations of product descriptions
- **Students** — Paraphrase academic texts for assignments
- **Bloggers** — Generate alternative versions of blog posts

---

## File Structure

```
article-rewriter/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `navigator.clipboard.writeText()`
- ES6 template literals

Recommended: Chrome 49+, Firefox 44+, Edge 12+, Safari 10+

---

## Limitations

⚠️ **Note:** This is a basic synonym-based rewriter. For advanced AI-powered rewriting, consider integrating with a language model API.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Content & Writing Tools**