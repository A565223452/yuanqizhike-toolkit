# Academic Citation Generator

A free, browser-based citation generator. Create citations in APA, MLA, Chicago, Harvard, IEEE, and AMA formats — no installation required.

---

## Features

- 📚 **6 Citation Styles** — APA 7th, MLA 9th, Chicago, Harvard, IEEE, AMA 11th
- 📄 **6 Document Types** — Book, Journal Article, Website, Conference Paper, Thesis, Video
- 📋 **One-Click Copy** — Copy generated citations instantly
- 💾 **History** — Save and retrieve past citations
- 🎯 **Smart Fields** — Dynamic form fields based on document type
- 🔒 **100% Private** — All processing happens locally; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works completely offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Select Document Type

Choose the type of source: Book, Journal Article, Website, Conference Paper, Thesis, or Video.

### Step 3: Fill in the Fields

Enter the required information:

| Field | Description |
|-------|-------------|
| **Author** | Last name, First Middle (e.g., Smith, John A.) |
| **Title** | Title of the work |
| **Year** | Publication year |
| **Publisher** | Publisher name, journal, or website |

Optional fields (volume, DOI, URL, edition) appear based on document type.

### Step 4: Choose Citation Style

Select from APA 7th, MLA 9th, Chicago, Harvard, IEEE, or AMA 11th Edition.

### Step 5: Generate & Copy

Click **Generate Citation**, then **Copy Citation** to save to clipboard.

---

## Supported Citation Styles

| Style | Description | Common Use |
|-------|-------------|------------|
| **APA 7th** | American Psychological Association | Social Sciences |
| **MLA 9th** | Modern Language Association | Humanities |
| **Chicago** | Chicago Manual of Style | General Publishing |
| **Harvard** | Author-Date System | Academic Journals |
| **IEEE** | Institute of Electrical and Electronics Engineers | Engineering & Tech |
| **AMA 11th** | American Medical Association | Medicine |

---

## Example Citations

### Book (APA 7th)

```
Smith, J. A. (2024). The Art of Programming. Oxford University Press.
```

### Journal Article (APA 7th)

```
Smith, J. A. (2024). Title of article. Journal Name, 10(2), 123-145. https://doi.org/10.1234/example.doi
```

### Website (MLA 9th)

```
Smith, John. "Title of Page." Website Name, 2024. https://example.com/page. Accessed 1 Jan. 2025.
```

---

## Use Cases

- **Students** — Create citations for research papers and essays
- **Researchers** — Generate references for journal submissions
- **Academics** — Format bibliographies for publications
- **Librarians** — Help patrons create citations

---

## File Structure

```
citation-generator/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `localStorage` for citation history
- `navigator.clipboard.writeText()`

Recommended: Chrome 50+, Firefox 44+, Edge 12+, Safari 10+

---

## Limitations

⚠️ **Note:** This is a basic citation generator. For complex citations or specialized styles, consider using a dedicated reference manager like Zotero, Mendeley, or EndNote.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Education & Research Tools**