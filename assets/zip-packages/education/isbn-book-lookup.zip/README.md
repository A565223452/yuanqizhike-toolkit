# ISBN Lookup Tool

A free, browser-based ISBN lookup. Search book metadata by ISBN-10 or ISBN-13 — no installation required.

---

## Features

- Search by ISBN-10/13
- Book metadata (title/author/publisher)
- Cover image
- Price comparison
- Export citation
- Open Library API

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Librarians**
- **Booksellers**
- **Researchers**
- **Students**
- **Collectors**

---

## File Structure

```
isbn-lookup/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Text & Content Tools**