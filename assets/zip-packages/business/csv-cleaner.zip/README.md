# CSV Order Data Cleaner (Shopify / Amazon)

A free, browser-based CSV data cleaning tool. Clean, deduplicate, and prepare order data for Shopify, Amazon, or any e-commerce platform — no installation required.

---

## Features

- 📂 **File Upload** — Drag & drop or click to upload CSV files
- 🧹 **Multiple Cleaning Options** — Remove empty rows, duplicates, blank fields, and more
- 📊 **Data Preview** — View cleaned data in a table format
- 📥 **One-Click Download** — Download cleaned CSV instantly
- 📈 **Statistics** — See how many rows were removed during cleaning
- 🔒 **100% Private** — All processing happens locally; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works completely offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Upload CSV File

Click the upload area or drag and drop your CSV file. Supports `.csv` and `.txt` (comma-separated) files.

### Step 3: Select Cleaning Options

| Option | Description |
|--------|-------------|
| **Remove Empty Rows** | Delete rows with no content |
| **Remove Duplicate Rows** | Delete duplicate entries |
| **Trim Spaces** | Remove leading and trailing whitespace |
| **Normalize Line Endings** | Standardize line breaks |

### Step 4: Clean Data

Click **Clean Data** to process the file. View statistics showing how many rows were removed.

### Step 5: Preview & Download

Click **Preview Table** to view the data in a table format. Click **Download Clean CSV** to save the cleaned file.

---

## Use Cases

- **E-commerce Sellers** — Clean order exports from Shopify, Amazon, eBay
- **Data Analysts** — Prepare CSV data for analysis
- **Marketing Teams** — Deduplicate customer email lists
- **Operations** — Clean inventory spreadsheets

---

## File Structure

```
csv-cleaner/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `<input type="file">`
- `FileReader` API
- `Blob` and `URL.createObjectURL`

Recommended: Chrome 50+, Firefox 44+, Edge 12+, Safari 10+

---

## Limitations

⚠️ **Note:** This is a basic CSV cleaner. For complex data transformations, consider using a spreadsheet application or dedicated data cleaning tool.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Business & Productivity Tools**