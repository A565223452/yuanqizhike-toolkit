# Amazon Keyword Research Tool

A free, browser-based Amazon keyword research tool. Find high-volume keywords for your Amazon listings — no installation required.

---

## Features

- Find high-volume keywords for Amazon listings
- Analyze competitor keywords
- Estimate search volume
- Export keyword data
- Filter by relevance

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Amazon sellers**
- **E-commerce marketers**
- **Product researchers**
- **FBA sellers**

---

## File Structure

```
amazon-keyword-miner/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Business & Productivity Tools**