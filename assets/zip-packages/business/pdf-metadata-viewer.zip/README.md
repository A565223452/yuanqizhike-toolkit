# PDF Metadata Viewer

A free, browser-based PDF metadata viewer. View document properties, author, dates, and more — no installation required.

---

## Features

- View PDF properties
- Author/title/subject
- Creation/modification dates
- Page count
- Font info
- Security settings

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Document managers**
- **Researchers**
- **Archivists**
- **Legal**
- **Compliance**

---

## File Structure

```
pdf-metadata-viewer/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — PDF Tools**