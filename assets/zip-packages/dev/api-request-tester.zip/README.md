# API Request Tester

A free, browser-based API testing tool. Send HTTP requests and inspect responses — no installation required.

---

## Features

- Send HTTP requests
- REST/GraphQL support
- Auth helpers
- History/collections
- Environment variables
- Response validation

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Backend developers**
- **API testers**
- **Integration engineers**
- **Frontend developers**
- **DevOps**

---

## File Structure

```
api-request-tester/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**