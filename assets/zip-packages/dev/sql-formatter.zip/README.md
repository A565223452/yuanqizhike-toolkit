# SQL Formatter

A free, browser-based SQL formatter. Format SQL queries for MySQL, PostgreSQL, SQLite — no installation required.

---

## Features

- Format SQL (MySQL/PostgreSQL/SQLite)
- Keyword casing
- Indentation
- Align clauses
- Minify option
- Dialect detection

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **DBAs**
- **Backend developers**
- **Data analysts**
- **Code reviewers**
- **Migration scripts**

---

## File Structure

```
sql-formatter/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**