# JSON Formatter / Validator

A free, browser-based JSON formatting and validation tool. No installation required — works entirely offline in your browser.

---

## Features

- ✨ **Format JSON** — Beautify and indent your JSON for better readability
- 📦 **Minify JSON** — Compress JSON into a single line by removing extra whitespace
- ✅ **Validate JSON** — Instantly detect and report syntax errors
- 🌳 **Tree View** — Interactive collapsible tree with color-coded values
- 📂 **Import File** — Load JSON from .json or .txt files
- 💾 **Export File** — Download formatted JSON as a file
- 📋 **Copy Result** — One-click copy to clipboard
- 📄 **Copy Node** — Copy individual tree node values
- 🔒 **Privacy First** — All processing happens locally; no data is sent to any server

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Paste Your JSON

Copy your JSON data and paste it into the text area.

### Step 3: Choose an Action

| Button          | Description                                                                 |
|-----------------|-----------------------------------------------------------------------------|
| **Format**      | Indents and formats your JSON with 2-space indentation for readability.     |
| **Minify**      | Removes all unnecessary whitespace to produce a compact, single-line JSON.  |
| **📂 Import**   | Load a JSON or text file from your computer.                                |
| **💾 Export**   | Download the current content as a `.json` file.                             |
| **Clear**       | Clears the input area and resets the editor.                                |
| **Copy**        | Copies the current content of the text area to your clipboard.              |

### View Modes

| Mode        | Description                                                                 |
|-------------|-----------------------------------------------------------------------------|
| **Code View** | Traditional textarea for editing raw JSON text.                            |
| **Tree View** | Interactive collapsible tree with color-coded values and copy buttons.    |

### Step 4: Check for Errors

If your JSON contains syntax errors, an error message will appear in red below the text area, indicating the issue.

---

## Example

### Input (Compact JSON)

```json
{"name":"John","age":30,"hobbies":["reading","gaming"]}
```

### Output (Formatted JSON)

```json
{
  "name": "John",
  "age": 30,
  "hobbies": [
    "reading",
    "gaming"
  ]
}
```

---

## File Structure

```
json-formatter/
├── index.html      # Main tool file (all features in one file)
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `JSON.parse()` / `JSON.stringify()`
- `navigator.clipboard.writeText()`

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**