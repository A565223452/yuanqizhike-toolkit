# AES Encryption/Decryption Tool

A free, browser-based AES encryption tool. Encrypt and decrypt text or files with military-grade security — no installation required.

---

## Features

- AES-256 encryption
- Encrypt/decrypt text/files
- Key derivation (PBKDF2)
- Base64/Hex output
- Offline operation
- GCM/CBC modes

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Developers**
- **Security researchers**
- **Privacy users**
- **DevOps**
- **Compliance teams**

---

## File Structure

```
aes-encryptor/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**