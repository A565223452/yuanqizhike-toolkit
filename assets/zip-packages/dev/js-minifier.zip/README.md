# JavaScript Minifier

A free, browser-based JavaScript minifier. Minify ES6+ code with source map support — no installation required.

---

## Features

- Minify ES6+ code
- Source maps
- Variable renaming
- Dead code removal
- Benchmark size reduction
- ES module support

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Frontend developers**
- **Build pipelines**
- **Performance optimization**
- **Library authors**
- **CI/CD**

---

## File Structure

```
js-minifier/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**