# Text Encoding Converter & Fixer

A free, browser-based text encoding tool. Detect and fix character encoding issues — no installation required.

---

## Features

- Detect and fix encoding issues
- Convert between UTF-8/GBK/ISO-8859
- Batch file processing
- Preview before save
- BOM handling

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Developers**
- **Data analysts**
- **Content migrators**
- **Legacy system users**
- **Localization teams**

---

## File Structure

```
encoding-fixer/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Content & Writing Tools**