# CSS Gradient Generator

A free, browser-based CSS gradient generator. Create beautiful linear gradients visually and copy the ready-to-use CSS code — no installation required.

---

## Features

- 🎨 **Visual Gradient Preview** — See your gradient in real-time as you adjust colors and angle
- 🌈 **Multi-Color Stops** — Add unlimited colors with custom position control
- 🔄 **3 Gradient Types** — Linear, Radial, and Conic gradients
- 📐 **360° Angle Control** — Fine-tune the gradient direction with a slider
- 🎭 **12 Popular Presets** — One-click apply beautiful preset gradients
- ➕ **Add/Remove Colors** — Dynamically manage color stops
- 📋 **One-Click Copy** — Copy the generated CSS code to clipboard instantly
- 🔒 **100% Private** — All processing happens locally; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works completely offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Choose Gradient Type

Select one of three gradient types:
- **Linear** — Smooth transition in a straight line
- **Radial** — Circular gradient expanding outward from center
- **Conic** — Rotating gradient around a center point

### Step 3: Manage Color Stops

Click **+ Add Color** to add more color stops. Each color stop has:
- A color picker for selecting the color
- A percentage field for positioning (0%–100%)

Click **✕** on any color stop (except the first two) to remove it.

### Step 4: Adjust the Angle

Use the **Angle slider** to change the gradient direction from 0° to 360°.

- **0deg** — Gradient flows from bottom to top
- **90deg** — Gradient flows from left to right
- **180deg** — Gradient flows from top to bottom
- **270deg** — Gradient flows from right to left

### Step 5: Copy the CSS Code

The generated CSS code appears in the text area below the controls. Click **Copy CSS Code** to copy it to your clipboard.

---

## Generated CSS Code

The tool generates CSS in the following formats:

### Linear Gradient
```css
background: linear-gradient(90deg, #2196F3 0%, #4CAF50 100%);
```

### Radial Gradient
```css
background: radial-gradient(circle, #2196F3, #4CAF50);
```

### Conic Gradient
```css
background: conic-gradient(from 90deg, #2196F3, #4CAF50);
```

You can paste this directly into your stylesheet or inline styles.

---

## Gradient Angle Guide

| Angle | Direction |
|-------|-----------|
| 0deg | Bottom → Top |
| 45deg | Bottom-Left → Top-Right |
| 90deg | Left → Right |
| 135deg | Top-Left → Bottom-Right |
| 180deg | Top → Bottom |
| 225deg | Top-Right → Bottom-Left |
| 270deg | Right → Left |
| 315deg | Bottom-Right → Top-Left |

---

## Popular Gradient Presets

The tool includes **12 built-in presets** for quick inspiration:

| Name | Colors | Best Angle |
|------|--------|------------|
| Sky | `#87CEEB` → `#1E90FF` | 180deg |
| Sunset | `#FF6B6B` → `#FFE66D` | 90deg |
| Ocean | `#00B4DB` → `#0083B0` | 180deg |
| Aurora | `#11998E` → `#38EF7D` | 45deg |
| Fire | `#F12711` → `#F5AF19` | 180deg |
| Purple Dream | `#667EEA` → `#764BA2` | 90deg |
| Neon | `#00F260` → `#0575E6` | 135deg |
| Rose | `#ED4264` → `#FFEDBC` | 180deg |
| Midnight | `#0C3483` → `#A2B6DF` | 180deg |
| Peach | `#ff9a9e` → `#fecfef` | 135deg |
| Tech | `#667eea` → `#764ba2` | 90deg |
| Corporate | `#2c3e50` → `#3498db` | 180deg |

---

## File Structure

```
css-gradient-generator/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `<input type="color">`
- CSS `linear-gradient()`
- `navigator.clipboard.writeText()`

Recommended: Chrome 49+, Firefox 47+, Edge 79+, Safari 9+

---

## Use Cases

- **Web Developers** — Quickly generate gradient backgrounds for websites
- **UI/UX Designers** — Prototype gradient effects before implementing in design tools
- **Frontend Developers** — Create eye-catching hero sections and card backgrounds
- **Students** — Learn about CSS gradients and color theory
- **Bloggers** — Add visual appeal to web pages without design experience

---

## Tips & Best Practices

- **Contrast Matters** — Ensure text remains readable over your gradient background
- **Subtle is Better** — Use gradients sparingly as accents rather than dominant elements
- **Dark Mode** — Darker gradients work well for dark mode backgrounds
- **Performance** — CSS gradients are GPU-accelerated and perform better than image backgrounds
- **Multi-Color** — More than 2 colors create smoother transitions across the spectrum
- **Fallbacks** — Consider adding a solid color fallback for older browsers:
  ```css
  background: #2196F3; /* Fallback */
  background: linear-gradient(90deg, #2196F3, #4CAF50);
  ```

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Frontend Visual Tools**