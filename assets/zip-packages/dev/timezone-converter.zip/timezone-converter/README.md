# Global Time Zone Converter

A free, browser-based time zone converter. Instantly compare dates and times across different time zones — no installation required.

---

## Features

- 🌍 **Multi-Timezone Support** — Compare times across major world time zones
- ⚡ **Instant Conversion** — See results in real-time as you select date and time
- 🕐 **Pre-configured Cities** — Quick access to New York, Berlin, Shanghai, London, and Los Angeles
- 📊 **Multi-Timezone Comparison** — View all timezones side by side
- 📅 **Date & Time Picker** — Easy-to-use date and time selection interface
- 🤝 **Meeting Time Generator** — Find optimal meeting times (9AM–3AM slots)
- 🌐 **World Clock** — Live clock showing current time in 10 major cities
- 🌅 **DST Indicator** — Shows Daylight Saving Time status for each timezone
- 🔒 **100% Private** — All processing happens locally; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works completely offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Select Your Local Timezone

Choose your current location from the **Your Local Timezone** dropdown menu.

Available options:
- **New York (EST)** — Eastern Standard Time
- **Berlin (CET)** — Central European Time
- **Shanghai (CST)** — China Standard Time
- **London (GMT)** — Greenwich Mean Time
- **Los Angeles (PST)** — Pacific Standard Time

### Step 3: Select Target Timezone

Choose the timezone you want to compare against from the **Target Timezone** dropdown menu.

### Step 4: Pick a Date and Time

Use the date and time picker to select the date and time you want to convert. The tool defaults to the current date and time (rounded to the nearest minute).

### Step 5: View the Result

The converted times for both timezones will be displayed immediately below the picker.

---

## Multi-Timezone Comparison

Scroll down to see all configured timezones compared side by side, including:
- Current date and time in each timezone
- DST (Daylight Saving Time) status indicator

---

## Meeting Time Generator

Find the best meeting time for international teams:

1. Click a preset button (9AM, 10AM, 11AM, 1PM, 2PM, or 3PM)
2. The tool automatically sets the date/time and shows all timezones
3. Click **Copy to Clipboard** to copy the meeting schedule

---

## World Clock

View the current time in 10 major world cities, updated every minute. Each city shows:
- City name and timezone
- Current local time
- DST status badge

---

## Example Scenarios

### Scenario 1: Schedule a Call with New York

You're in **London** and want to call a colleague in **New York**.

1. Select **London (GMT)** as your local timezone
2. Select **New York (EST)** as the target timezone
3. Pick a date and time (e.g., Monday, 2:00 PM)
4. The result shows what time it is in New York at that moment

### Scenario 2: Coordinate with Shanghai Team

You're in **Los Angeles** and need to schedule a meeting with your team in **Shanghai**.

1. Select **Los Angeles (PST)** as your local timezone
2. Select **Shanghai (CST)** as the target timezone
3. Pick a date and time
4. See the corresponding time in Shanghai

---

## Available Time Zones

| City | Timezone ID | Standard Time | UTC Offset |
|------|-------------|---------------|------------|
| New York | `America/New_York` | EST (Eastern Standard Time) | UTC-5 |
| Berlin | `Europe/Berlin` | CET (Central European Time) | UTC+1 |
| Shanghai | `Asia/Shanghai` | CST (China Standard Time) | UTC+8 |
| London | `Europe/London` | GMT (Greenwich Mean Time) | UTC+0 |
| Los Angeles | `America/Los_Angeles` | PST (Pacific Standard Time) | UTC-8 |

---

## Time Difference Quick Reference

| From → To | New York | Berlin | Shanghai | London | Los Angeles |
|-----------|----------|--------|----------|--------|-------------|
| **New York** | — | +6h | +12h | +5h | -3h |
| **Berlin** | -6h | — | +6h | +1h | -9h |
| **Shanghai** | -12h | -6h | — | -8h | -16h |
| **London** | -5h | -1h | +8h | — | -8h |
| **Los Angeles** | +3h | +9h | +16h | +8h | — |

*Note: Time differences may vary during Daylight Saving Time (DST) periods.*

---

## Understanding the Output

The result box displays two lines:

```
Local(America/New_York): 1/15/2025, 2:00:00 PM
Target(Asia/Shanghai): 1/16/2025, 2:00:00 AM
```

- **First line** — The date and time in your selected local timezone
- **Second line** — The equivalent date and time in the target timezone
- The format follows US conventions (MM/DD/YYYY, 12-hour clock)

---

## File Structure

```
timezone-converter/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `<input type="datetime-local">`
- `Date.toLocaleString()` with `timeZone` option
- `Intl.DateTimeFormat`

Recommended: Chrome 35+, Firefox 29+, Edge 12+, Safari 10+

---

## Use Cases

- **Remote Teams** — Schedule meetings across different time zones
- **Travel Planning** — Plan flights and connections between cities
- **International Business** — Coordinate calls and deadlines with global clients
- **Event Organizers** — Set event times visible to attendees worldwide
- **Personal Use** — Stay in touch with friends and family in different regions

---

## Important Notes

⏰ **Daylight Saving Time (DST):**

- This tool uses the browser's built-in timezone handling, which automatically accounts for DST.
- Timezone offsets may differ by 1 hour during DST periods.
- DST start and end dates vary by country.

🌐 **Additional Timezones:**

- This tool includes 5 pre-configured timezones for quick access.
- For more timezone options, consider using a full-featured timezone library or expanding the `<select>` options in `index.html`.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**