# Base64 / URL Encoder & Decoder

A free, browser-based encoding and decoding tool. Instantly encode or decode text using Base64 or URL encoding — no installation required.

---

## Features

- 🔤 **Base64 Encode/Decode** — Convert text to/from Base64 format
- 🔗 **URL Encode/Decode** — Percent-encode text for safe URL transmission
- 🔑 **JWT Parser** — Decode and inspect JSON Web Token headers and payloads
- 📦 **Batch Processing** — Encode/decode multiple lines at once
- 🔐 **Hash Generator** — Generate MD5, SHA-1, SHA-256, SHA-512 hashes
- ⚡ **Instant Results** — Get encoded/decoded output with a single click
- 🛡️ **Error Handling** — Clear error messages for invalid input
- 🔒 **100% Private** — All processing happens locally; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works completely offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Enter Your Text

Type or paste your text into the input text area at the top.

### Step 3: Choose an Encoding Option

| Button | Description | Use Case |
|--------|-------------|----------|
| **Base64 Encode** | Converts text to Base64 format | Embedding binary data in text formats |
| **Base64 Decode** | Decodes Base64 text back to original | Reading encoded data from APIs or emails |
| **URL Encode** | Converts text to percent-encoded format | Preparing data for URL query strings |
| **URL Decode** | Decodes percent-encoded text back to original | Reading data from URLs or log files |
| **Clear** | Clears both input and output fields | Start fresh |

### Step 4: View the Result

The encoded or decoded output will appear in the bottom text area, which is read-only to prevent accidental edits.

---

## JWT Parser

Switch to the **JWT** tab to decode JSON Web Tokens:

1. Paste your JWT token
2. Click **Parse JWT**
3. View the decoded Header and Payload
4. Expiration date is automatically calculated if present

---

## Batch Processing

Switch to the **Batch** tab to process multiple lines:

1. Enter one item per line
2. Choose the operation (Base64 Encode/Decode, URL Encode/Decode)
3. Results are displayed line by line

---

## Hash Generator

Switch to the **Hash** tab to generate cryptographic hashes:

| Algorithm | Output Length | Use Case |
|-----------|--------------|----------|
| **MD5** | 32 characters | Checksums (not secure) |
| **SHA-1** | 40 characters | Legacy hashing |
| **SHA-256** | 64 characters | Security applications |
| **SHA-512** | 128 characters | High-security applications |

⚠️ Note: These are simplified hash implementations for demonstration purposes. For production security, use Web Crypto API.

---

## Examples

### Example 1: Base64 Encode

**Input:**
```
Hello, World!
```

**Click "Base64 Encode"**

**Result:**
```
SGVsbG8sIFdvcmxkIQ==
```

### Example 2: Base64 Decode

**Input:**
```
SGVsbG8sIFdvcmxkIQ==
```

**Click "Base64 Decode"**

**Result:**
```
Hello, World!
```

### Example 3: URL Encode

**Input:**
```
Hello World & foo=bar
```

**Click "URL Encode"**

**Result:**
```
Hello%20World%20%26%20foo%3Dbar
```

### Example 4: URL Decode

**Input:**
```
Hello%20World%20%26%20foo%3Dbar
```

**Click "URL Decode"**

**Result:**
```
Hello World & foo=bar
```

---

## Understanding Encoding Formats

### Base64

Base64 is a binary-to-text encoding scheme that represents binary data in an ASCII string format using a radix-64 alphabet.

**Character Set:**
- Uppercase letters: `A-Z`
- Lowercase letters: `a-z`
- Digits: `0-9`
- Special characters: `+`, `/`
- Padding: `=` (used at the end if needed)

**Common Use Cases:**
- Embedding images in HTML/CSS (data URIs)
- Sending binary data over text-based protocols (email, HTTP)
- JWT (JSON Web Tokens)
- API authentication tokens

**Limitations:**
- Increases data size by approximately 33%
- Not encryption — Base64 is easily reversible and provides no security

### URL Encoding (Percent-Encoding)

URL encoding converts special characters into a format that can be transmitted over the internet. Each character is replaced by a `%` followed by two hexadecimal digits.

**Common Encoded Characters:**

| Character | Encoded | Character | Encoded |
|-----------|---------|-----------|---------|
| Space | `%20` | `&` | `%26` |
| `!` | `%21` | `'` | `%27` |
| `#` | `%23` | `(` | `%28` |
| `$` | `%24` | `)` | `%29` |
| `%` | `%25` | `*` | `%2A` |
| `+` | `%2B` | `,` | `%2C` |
| `/` | `%2F` | `:` | `%3A` |
| `;` | `%3B` | `=` | `%3D` |
| `?` | `%3F` | `@` | `%40` |
| `[` | `%5B` | `]` | `%5D` |

**Common Use Cases:**
- Query strings in URLs (`?name=value&key=data`)
- Form data submission (application/x-www-form-urlencoded)
- Cookie values
- Embedding special characters in URLs

---

## Base64 vs URL Encoding — Which to Use?

| Scenario | Recommended Encoding |
|----------|---------------------|
| Sending binary data via email | Base64 |
| Embedding images in HTML/CSS | Base64 |
| URL query parameters | URL Encoding |
| Form data submission | URL Encoding |
| JWT tokens | Base64Url (variant of Base64) |
| API authentication headers | Base64 |

---

## File Structure

```
base64-url-tool/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `btoa()` / `atob()` — Base64 encoding/decoding
- `encodeURIComponent()` / `decodeURIComponent()` — URL encoding/decoding

Recommended: Chrome 1+, Firefox 1+, Edge 12+, Safari 3+

---

## Use Cases

- **Web Developers** — Debug and test URL query strings and Base64 data URIs
- **API Developers** — Encode/decode authentication tokens and request parameters
- **DevOps Engineers** — Decode credentials from configuration files
- **Security Analysts** — Analyze encoded payloads in security incidents
- **Students** — Learn about data encoding concepts

---

## Security Notes

⚠️ **Important:**

- This tool runs entirely in your browser. No data is ever sent to a server.
- Base64 is **not encryption**. Do not use it to protect sensitive information.
- Be cautious when decoding Base64 or URL-encoded data from untrusted sources — it may contain malicious content.
- Never paste highly sensitive data (passwords, API keys) into online tools. This offline tool is safe, but always exercise caution.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**