# Online Regex Tester

A free, browser-based regular expression testing tool. Test, validate, and debug your regex patterns instantly — no installation required.

---

## Features

- 🔍 **Real-time Matching** — Enter your regex pattern and test text to find all matches
- ⚡ **Instant Feedback** — Get immediate results with match details
- 📝 **Quick Templates** — Pre-built regex patterns for common use cases (Email, URL, Phone, IP, Numbers, HTML Tags)
- 📊 **Match Statistics** — Shows total and unique match counts
- 🎨 **Highlighted Matches** — Matched text is highlighted for easy identification
- 🛡️ **Error Handling** — Clear error messages for invalid regex patterns
- 🔒 **100% Private** — All processing happens in your browser; no data is sent to any server
- 📱 **Lightweight** — Single HTML file, works offline

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Enter Your Regular Expression

In the **Regular Expression** field, type your regex pattern. Or click a **Quick Template** button to auto-fill a common pattern.

**Quick Templates:**
- **Email** — Matches email addresses
- **URL** — Matches HTTP/HTTPS URLs
- **Phone** — Matches phone numbers (format: 123-4567)
- **IP** — Matches IP addresses
- **Numbers** — Matches numeric digits
- **HTML Tags** — Matches HTML tags

**Examples:**

| Pattern | Description |
|---------|-------------|
| `\w+@\w+\.\w+` | Email addresses |
| `\d{3}-\d{4}` | Phone numbers (format: 123-4567) |
| `<[^>]+>` | HTML tags |
| `\b\w{4}\b` | Words with exactly 4 letters |
| `https?:\/\/[^\s]+` | URLs |

### Step 3: Paste Your Test Text

In the **Test Text** area, paste or type the text you want to search through.

### Step 4: Click "Run Match"

Press the **Run Match** button to find all matches.

### Step 5: View Results

- **Matches found** — All matched strings will be displayed with highlights
- **Match count** — Shows total matches and unique match count
- **No matches** — A "No matches found." message will appear
- **Invalid regex** — An error message will show the specific issue with your pattern

---

## Examples

### Example 1: Find Email Addresses

**Regex:**
```
\w+@\w+\.\w+
```

**Test Text:**
```
Contact us at support@example.com or sales@test.org for more info.
```

**Result:**
```
Matches: support@example.com, sales@test.org
```

### Example 2: Find Numbers

**Regex:**
```
\d+
```

**Test Text:**
```
Order #12345 was placed on 2024-01-15. Total: 99 items.
```

**Result:**
```
Matches: 12345, 2024, 01, 15, 99
```

### Example 3: Find HTML Tags

**Regex:**
```
<[^>]+>
```

**Test Text:**
```
<p>Hello <b>World</b></p>
```

**Result:**
```
Matches: <p>, <b>, </b>, </p>
```

---

## Common Regex Patterns Reference

| Pattern | Meaning |
|---------|---------|
| `\d` | Any digit (0-9) |
| `\w` | Any word character (a-z, A-Z, 0-9, _) |
| `\s` | Any whitespace |
| `.` | Any character except newline |
| `*` | Zero or more occurrences |
| `+` | One or more occurrences |
| `?` | Zero or one occurrence |
| `[abc]` | Any character in brackets |
| `(a\|b)` | Either `a` or `b` |
| `^` | Start of string |
| `$` | End of string |

---

## File Structure

```
regex-tester/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `RegExp` object
- `String.prototype.match()`

Recommended: Chrome 60+, Firefox 55+, Edge 79+, Safari 11+

---

## Limitations

- Uses JavaScript's built-in `RegExp` engine (ECMAScript standard)
- Does not support advanced regex features like lookbehind assertions in older browsers
- Global flag (`g`) is automatically applied for multiple matches

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**