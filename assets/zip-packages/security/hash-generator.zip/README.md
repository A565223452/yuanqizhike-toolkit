# Hash Generator

A free, browser-based hash generator. Generate MD5, SHA1, SHA256, SHA512 hashes — no installation required.

---

## Features

- MD5/SHA1/SHA256/SHA512
- HMAC support
- File/text input
- Batch hashing
- Verify checksums
- Salt support

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Developers**
- **Security**
- **File integrity**
- **Blockchain**
- **Password storage**

---

## File Structure

```
hash-generator/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**