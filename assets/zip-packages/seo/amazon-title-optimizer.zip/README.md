# Amazon Product Title Optimizer

A free, browser-based Amazon title optimizer. Optimize your product titles for better SEO and conversions — no installation required.

---

## Features

- Optimize titles for SEO
- Character count checker
- Keyword placement suggestions
- A/B test title variations
- Competitor analysis

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Amazon sellers**
- **FBA sellers**
- **Product launch managers**
- **E-commerce marketers**

---

## File Structure

```
amazon-title-optimizer/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Business & Productivity CSV Tools**