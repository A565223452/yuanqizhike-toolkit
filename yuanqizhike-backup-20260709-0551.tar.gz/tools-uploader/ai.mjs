// AI 调用模块
// 1. analyzeTool：分析工具源代码 → 返回 { category, title, desc, features[] }
// 2. selectIcon：根据工具用途 + 该分类图标列表 → 返回最贴合的图标 path
// 使用 OpenAI 兼容接口。失败时回退，保证流程不中断。
import cfg from './config.mjs';
import { iconListForAI, iconPathByIndex, iconsMeta } from './icons-meta.mjs';

const SYSTEM_PROMPT = `你是一个前端工具分类与文案助手。用户会给你一个工具的源代码片段（主要是 index.html，可能含 JS/CSS）和文件夹名。
你的任务：
1. 从以下 27 个分类中选一个最匹配的：
   - "Content & Writing"（内容与写作：文字处理、文章、翻译、拼写、计数、博客、邮件、文档等）
   - "Design & Media"（设计与媒体：图片、颜色、视频、音频、画布、图标、Logo、海报等）
   - "Developer Tools"（开发者工具：代码、JSON、正则、编码、API、数据库、终端、Git、Docker 等）
   - "Business & Productivity"（商业与效率：表格、时间、任务、数据、报表、发票、报价、办公等）
   - "Education & Research"（教育与研究：引用、学术、笔记、词典、研究、实验等）
   - "Health & Fitness"（健康与健身：BMI、卡路里、体重、运动、跑步、心率、营养、睡眠等）
   - "Finance & Crypto"（金融与加密货币：贷款、利息、汇率、税务、工资、投资、加密货币、理财等）
   - "SEO & Marketing"（SEO 与营销：关键词、Meta 标签、SERP、反向链接、排名、社媒营销、Amazon SEO 等）
   - "Social Media"（社交媒体：Instagram/TikTok/YouTube/X 的字数计、标签生成、内容排版、emoji、帖子排版等）
   - "Lifestyle & Utilities"（生活常用：时区转换、日期计算、年龄计算、倒计时、随机数等）
   - "Security & Privacy"（安全隐私：密码生成、AES 加密、哈希、SSL、JWT、QR 码、密钥生成等）
   - "Math & Science"（数学与科学：方程求解、科学计算器、统计、微积分、物理、化学、单位换算等）
   - "AI & ML Utilities"（AI 与机器学习：Prompt 生成、Token 计数、模型计算、数据集工具等）
   - "Travel Tools"（旅行工具：距离计算、货币换算、行程规划、时区工具等）
   - "Cooking & Food"（烹饪与食物：食谱换算、烹饪计时器、营养计算等）
   - "Cars & Vehicles"（汽车与车辆：油耗计算、里程追踪、胎压换算、车辆维护等）
   - "Color & Design Utilities"（颜色与设计工具：取色器、调色板生成、渐变制作、对比度检查等）
   - "Forms & Generators"（表单与生成器：表单构建、模板生成、文档生成、代码生成等）
   - "Weather & Climate"（天气与气候：温度换算、体感温度、风寒、湿度计算等）
   - "Audio & Music Tools"（音频与音乐：音频转换、BPM 检测、频率计算、和弦查找等）
   - "Video Tools"（视频工具：视频格式转换、分辨率计算、码率工具、帧提取等）
   - "Photography Tools"（摄影工具：EXIF 查看、焦距计算、曝光工具、景深计算等）
   - "Gaming Tools"（游戏工具：骰子、属性计算、build 规划、灵敏度换算等）
   - "Hobbies & Crafts"（爱好与手工艺：图案生成、毛线计算、手工规划、针数计数等）
   - "Pets & Animals"（宠物与动物：宠物年龄、喂食指南、剂量计算、繁殖工具等）
   - "Real Estate Tools"（房地产工具：房贷计算、房产估价、ROI 计算、租金收益等）
   - "Religion & Spirituality"（宗教与灵性：祷告时间、宗教日历、冥想计时、经文工具等）
2. 生成工具的英文标题 title（Title Case，例如 "JSON Formatter"）
3. 生成一句英文介绍 desc（20-40 词，准确描述工具用途和亮点，SEO 友好）
4. 生成 3-6 个英文功能点 features（每个 3-6 词，例如 "Format and validate JSON"）

分类判断要点：
- 涉及"健康/BMI/卡路里/运动/跑步/体重"→ Health & Fitness
- 涉及"贷款/利息/汇率/税务/工资/投资/比特币/以太坊"→ Finance & Crypto
- 涉及"房贷/房产估价/ROI/租金收益"→ Real Estate Tools（不要归到 Finance & Crypto）
- 涉及"关键词分析/Meta 标签/SERP/反向链接/Amazon 关键词/排名"→ SEO & Marketing
- 涉及"Instagram/TikTok/YouTube/X 字数/标签/帖子/社媒"→ Social Media
- 涉及"时区/日期计算/年龄/倒计时/随机数"→ Lifestyle & Utilities
- 涉及"密码生成/AES 加密/哈希/SSL/JWT/密钥"→ Security & Privacy
- 涉及"代码/JSON/正则/编码/API/数据库"→ Developer Tools
- 涉及"发票/报价/表格/任务/时间管理/办公"→ Business & Productivity
- 涉及"图片/颜色/视频/音频/设计"→ Design & Media
- 涉及"文字/文章/翻译/拼写/字数"→ Content & Writing
- 涉及"引用/学术/笔记/研究"→ Education & Research
- 涉及"方程/科学计算器/统计/微积分/物理/化学"→ Math & Science
- 涉及"单位换算"→ Math & Science（科学单位换算归此处）
- 涉及"Prompt/Token/模型/数据集"→ AI & ML Utilities
- 涉及"距离/货币换算/行程/时区"→ Travel Tools
- 涉及"食谱/烹饪/营养"→ Cooking & Food
- 涉及"油耗/里程/胎压/车辆"→ Cars & Vehicles
- 涉及"取色器/调色板/渐变/对比度"→ Color & Design Utilities
- 涉及"表单构建/模板生成/文档生成"→ Forms & Generators
- 涉及"温度换算/体感温度/风寒/湿度"→ Weather & Climate
- 涉及"音频转换/BPM/频率/和弦"→ Audio & Music Tools
- 涉及"视频格式/分辨率/码率/帧"→ Video Tools
- 涉及"EXIF/焦距/曝光/景深"→ Photography Tools
- 涉及"骰子/属性/build/灵敏度"→ Gaming Tools
- 涉及"图案/毛线/手工/针数"→ Hobbies & Crafts
- 涉及"宠物年龄/喂食/剂量/繁殖"→ Pets & Animals
- 涉及"祷告/宗教日历/冥想/经文"→ Religion & Spirituality

特别注意：
- AES Encryptor、Password Generator、Hash Generator 这类安全工具 → Security & Privacy（不要归到 Developer Tools）
- Time Zone Converter、Unit Converter 这类生活工具 → Lifestyle & Utilities（不要归到 Developer Tools）
- Instagram 字数计、Twitter 字符计数器 → Social Media（不要归到 Content & Writing）
- Scientific Calculator、Equation Solver、Statistics Calculator → Math & Science（不要归到 Education & Research）
- Color Picker、Palette Generator、Gradient Maker → Color & Design Utilities（不要归到 Design & Media）
- Mortgage Calculator → Real Estate Tools（不要归到 Finance & Crypto）
- Temperature Converter、Heat Index → Weather & Climate（不要归到 Lifestyle & Utilities）

只返回一个 JSON 对象，不要任何解释、不要 markdown 代码块，格式：
{"category":"...","title":"...","desc":"...","features":["...","..."]}

# 示例（Few-shot）

输入：
文件夹名: bmi-calculator
--- 文件: index.html ---
<!DOCTYPE html><title>BMI Calculator</title>
<input id="weight"><input id="height"><button onclick="calc()">Calculate BMI</button>
<script>function calc(){ const w=+weight.value, h=+height.value/100; bmi=(w/(h*h)).toFixed(1); ... }</script>

输出：
{"category":"Health & Fitness","title":"BMI Calculator","desc":"Calculate your Body Mass Index instantly with our free online BMI calculator. Enter your height and weight to check if your weight is in a healthy range.","features":["Instant BMI calculation","Metric and imperial units","Healthy range indicator","No signup required"]}

输入：
文件夹名: loan-calculator
--- 文件: index.html ---
<title>Mortgage Loan Calculator</title>
<input id="amount"><input id="rate"><input id="years">
<script>function calc(){ const p=+amount.value; const r=+rate.value/100/12; const n=+years.value*12; ... }</script>

输出：
{"category":"Finance & Crypto","title":"Mortgage Loan Calculator","desc":"Calculate monthly mortgage payments, total interest, and amortization schedules. Free online loan calculator for home, auto, and personal loans with detailed breakdowns.","features":["Monthly payment calculation","Total interest computed","Amortization schedule","Supports multiple loan types"]}

输入：
文件夹名: keyword-density-checker
--- 文件: index.html ---
<title>Keyword Density Checker</title>
<textarea id="content"></textarea><button onclick="analyze()">Analyze</button>
<script>function analyze(){ const words=content.value.split(/\\s+/); const freq={}; ... }</script>

输出：
{"category":"SEO & Marketing","title":"Keyword Density Checker","desc":"Analyze keyword density and frequency in your content for better SEO optimization. Identify over-optimized keywords and improve your search engine rankings.","features":["Real-time density analysis","Top keywords highlighted","SEO optimization tips","Word frequency count"]}`;

const ICON_PROMPT = `你是一个图标选择助手。用户会给你一个工具的标题、介绍、功能列表，以及该分类下可选的图标列表（每行格式 [编号] 图标描述）。
请根据工具的实际用途和核心功能，从列表中选择最贴切、最能让用户一眼看懂工具作用的图标。

选择原则：
- 优先匹配工具的核心动作（如"计算"→Calculator，"分析"→Magnifier Chart）
- 其次匹配工具的对象（如"贷款"→Bank，"密码"→Key）
- 避免选含义模糊的图标（如 "Connect Nodes" 这种太通用的）

只返回图标的编号（一个数字），不要任何解释、不要其它字符。`;

// 调用 AI 分析工具（第一次调用）
export async function analyzeTool({ folderName, fileContents }) {
  const userMsg = buildUserMessage(folderName, fileContents);
  try {
    const data = await callAI(SYSTEM_PROMPT, userMsg);
    const parsed = parseJsonLoose(data);
    if (!parsed) throw new Error('AI 返回内容无法解析为 JSON');
    return normalize(parsed, folderName);
  } catch (err) {
    return fallback(folderName, err.message);
  }
}

// 调用 AI 选图标（第二次调用）。传入分类、标题、介绍、功能列表，返回图标 path
// usedIcons: 已占用的图标 path 集合，AI 选中的若被占用则取该分类下一个未占用的
export async function selectIcon({ category, title, desc, features = [], usedIcons = new Set() }) {
  const list = iconsMeta[category] || [];
  if (list.length === 0) return '';

  // 构建可选图标列表（排除已占用的，给 AI 看完整列表让它选，占用判断在后面处理）
  const iconListText = iconListForAI(category);
  const featuresText = features.length > 0 ? features.join('、') : '无';
  const userMsg = `工具标题: ${title}\n工具介绍: ${desc}\n核心功能: ${featuresText}\n\n可选图标列表（[编号] 描述）：\n${iconListText}\n\n请根据工具的核心功能和对象，返回最贴切的图标编号。`;

  // 自我校验 + 重试机制：最多调用 2 次
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const content = await callAI(ICON_PROMPT, userMsg, 0.2);
      // 提取第一个数字
      const m = String(content).match(/\d+/);
      if (m) {
        const idx = parseInt(m[0], 10);
        // 校验：编号在合法范围内
        if (idx >= 0 && idx < list.length) {
          const path = iconPathByIndex(category, idx);
          if (path) {
            // 若被占用，沿编号往后找第一个未占用的
            if (!usedIcons.has(path)) return path;
            for (let i = 0; i < list.length; i++) {
              const p = list[i].path;
              if (!usedIcons.has(p)) return p;
            }
            return path; // 全占用则用 AI 选的
          }
        }
        // 编号非法，第二次尝试
        if (attempt === 0) continue;
      }
      // AI 返回异常，回退：取该分类第一个未占用的
      return firstAvailable(category, usedIcons);
    } catch (_) {
      if (attempt === 0) continue;
      return firstAvailable(category, usedIcons);
    }
  }
  return firstAvailable(category, usedIcons);
}

// 取该分类第一个未占用的图标
function firstAvailable(category, usedIcons) {
  const list = iconsMeta[category] || [];
  for (const it of list) {
    if (!usedIcons.has(it.path)) return it.path;
  }
  return list[0] ? list[0].path : '';
}

// 通用 AI 调用
async function callAI(systemPrompt, userMsg, temperature = 0.3) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), cfg.ai.timeoutMs);

  const res = await fetch(cfg.ai.baseUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${cfg.ai.apiKey}`,
    },
    body: JSON.stringify({
      model: cfg.ai.model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMsg },
      ],
      temperature,
    }),
    signal: controller.signal,
  });
  clearTimeout(timer);

  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    throw new Error(`AI HTTP ${res.status}: ${txt.slice(0, 200)}`);
  }

  const data = await res.json();
  return data?.choices?.[0]?.message?.content || '';
}

function buildUserMessage(folderName, fileContents) {
  const parts = [`文件夹名: ${folderName}`];
  for (const [name, text] of Object.entries(fileContents)) {
    const limited = (text || '').slice(0, cfg.maxContentChars);
    parts.push(`--- 文件: ${name} ---\n${limited}`);
  }
  return parts.join('\n\n');
}

// 容错 JSON 解析：先直接 parse，失败则正则提取第一个 {...}
function parseJsonLoose(content) {
  if (!content) return null;
  const trimmed = content.trim();
  try {
    return JSON.parse(trimmed);
  } catch (_) {
    const match = trimmed.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        return JSON.parse(match[0]);
      } catch (_) {
        return null;
      }
    }
  }
  return null;
}

// 规范化 AI 返回，确保字段类型与分类合法
function normalize(parsed, folderName) {
  const validCats = Object.keys(cfg.categoryMap);
  let category = typeof parsed.category === 'string' ? parsed.category.trim() : '';
  if (!validCats.includes(category)) {
    category = cfg.fallbackCategory;
  }

  let title = typeof parsed.title === 'string' ? parsed.title.trim() : '';
  if (!title) title = toTitleCase(folderName);

  let desc = typeof parsed.desc === 'string' ? parsed.desc.trim() : '';
  if (!desc) desc = `${title} - a handy browser-based tool.`;

  let features = Array.isArray(parsed.features) ? parsed.features : [];
  features = features
    .filter((f) => typeof f === 'string' && f.trim())
    .map((f) => f.trim())
    .slice(0, 6);
  if (features.length === 0) features = ['Easy to use', 'Works offline'];

  return {
    category,
    title,
    desc,
    features,
    aiOk: true,
  };
}

function fallback(folderName, errMsg) {
  const title = toTitleCase(folderName);
  return {
    category: cfg.fallbackCategory,
    title,
    desc: `${title} - a handy browser-based tool.`,
    features: ['Easy to use', 'Works offline'],
    aiOk: false,
    aiError: errMsg,
  };
}

function toTitleCase(slug) {
  return String(slug || 'tool')
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : ''))
    .join(' ');
}
