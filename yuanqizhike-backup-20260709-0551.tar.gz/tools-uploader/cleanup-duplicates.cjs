// 清理 tools-list.json 中确认的重复项
// 用法：node cleanup-duplicates.cjs
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const LIST_PATH = path.join(ROOT, 'tools-list.json');
const ZIP_ROOT = ROOT; // zipUrl 相对根目录

// 确认要删除的 zipUrl 列表（旧版，保留新版）
const TO_DELETE = [
  'assets/zip-packages/dev/css-gradient-generator.zip',          // 删 [3]，留 [84]
  'assets/zip-packages/design/css-gradient-generator.zip',       // 删 [46]，留 [84]
  'assets/zip-packages/dev/regex-tester.zip',                    // 删 [4]，留 [71]
  'assets/zip-packages/business/csv-cleaner.zip',                // 删 [8]，留 [18]
  'assets/zip-packages/education/citation-generator.zip',        // 删 [9]，留 [94]
  'assets/zip-packages/dev/meta-tag-generator.zip',              // 删 [95]，留 [118]
  'assets/zip-packages/writing/markdown-to-html-converter.zip',  // 删 [29]，留 [113]
  'assets/zip-packages/dev/timezone-converter.zip',              // 删 [1]，留 [77]/[108]
];

// 安全备份
const BAK_PATH = LIST_PATH + '.cleanup-bak-' + Date.now();
fs.writeFileSync(BAK_PATH, fs.readFileSync(LIST_PATH), 'utf8');
console.log('已备份 tools-list.json -> ' + path.basename(BAK_PATH));

const list = JSON.parse(fs.readFileSync(LIST_PATH, 'utf8'));
console.log('清理前总数: ' + list.length);

const deleteSet = new Set(TO_DELETE);
const removed = [];
const newList = list.filter(t => {
  if (deleteSet.has(t.zipUrl)) {
    removed.push(t);
    return false;  // 删除
  }
  return true;     // 保留
});

// 删除对应的 zip 文件
let zipDeleted = 0;
let zipMissing = 0;
removed.forEach(t => {
  const zipAbs = path.join(ZIP_ROOT, t.zipUrl);
  if (fs.existsSync(zipAbs)) {
    fs.unlinkSync(zipAbs);
    zipDeleted++;
    console.log('  ✓ 删除 zip: ' + t.zipUrl);
  } else {
    zipMissing++;
    console.log('  - zip 不存在: ' + t.zipUrl);
  }
});

// 写回 tools-list.json
fs.writeFileSync(LIST_PATH, JSON.stringify(newList, null, 2) + '\n', 'utf8');

console.log('\n=== 清理结果 ===');
console.log('删除 tools-list.json 条目: ' + removed.length);
console.log('删除 zip 文件: ' + zipDeleted + ' 个');
console.log('缺失 zip 文件: ' + zipMissing + ' 个（已忽略）');
console.log('清理后总数: ' + newList.length);
console.log('\n已删除的工具:');
removed.forEach((t, i) => {
  console.log('  ' + (i+1) + '. [' + t.title + '] -> ' + t.zipUrl);
});
