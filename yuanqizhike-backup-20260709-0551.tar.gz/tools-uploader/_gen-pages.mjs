// 批量生成 16 个新分类页面 - 基于 finance.html 模板做字面量替换
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const templatePath = path.join(root, 'tools', 'finance.html');
const template = fs.readFileSync(templatePath, 'utf8');

// 模板中需要被替换的原始值
const ORIG = {
  name: 'Finance & Crypto',
  trackSlug: 'finance-crypto',
  fileName: 'finance.html',
  emoji: '&#128181;',
  metaDesc: 'Free offline finance and crypto calculators. Loan, compound interest, currency converters, and tax estimators that run locally.',
  heroDesc: 'Loan calculators, compound interest, crypto converters, and tax estimators. All processing runs locally in your browser.',
};

// 16 个新分类配置
const cats = [
  { name: 'Math & Science', slug: 'math', emoji: '&#129518;', trackSlug: 'math-science',
    metaDesc: 'Free offline math and science calculators. Equation solvers, unit converters, scientific calculators, and statistics tools that run locally.',
    heroDesc: 'Scientific calculators, equation solvers, unit converters, statistics tools, and math utilities. All processing runs locally in your browser.' },
  { name: 'AI & ML Utilities', slug: 'ai', emoji: '&#129302;', trackSlug: 'ai-ml-utilities',
    metaDesc: 'Free offline AI and ML utility tools. Prompt generators, token counters, model calculators, and dataset utilities that run locally.',
    heroDesc: 'Prompt generators, token counters, model size calculators, dataset tools, and ML utilities. All processing runs locally in your browser.' },
  { name: 'Travel Tools', slug: 'travel', emoji: '&#9992;', trackSlug: 'travel-tools',
    metaDesc: 'Free offline travel tools. Distance calculators, currency converters, trip planners, and time zone converters for travelers.',
    heroDesc: 'Distance calculators, currency converters, trip planners, time zone tools, and travel utilities. All processing runs locally in your browser.' },
  { name: 'Cooking & Food', slug: 'cooking', emoji: '&#127859;', trackSlug: 'cooking-food',
    metaDesc: 'Free offline cooking and food tools. Recipe converters, cooking timers, unit converters, and nutrition calculators that run locally.',
    heroDesc: 'Recipe converters, cooking timers, unit converters, nutrition calculators, and food utilities. All processing runs locally in your browser.' },
  { name: 'Cars & Vehicles', slug: 'cars', emoji: '&#128663;', trackSlug: 'cars-vehicles',
    metaDesc: 'Free offline car and vehicle tools. Fuel calculators, mileage trackers, tire pressure converters, and vehicle maintenance utilities.',
    heroDesc: 'Fuel calculators, mileage trackers, tire pressure converters, vehicle maintenance tools, and auto utilities. All processing runs locally in your browser.' },
  { name: 'Color & Design Utilities', slug: 'color', emoji: '&#127912;', trackSlug: 'color-design-utilities',
    metaDesc: 'Free offline color and design tools. Color pickers, palette generators, gradient makers, and design utilities that run locally.',
    heroDesc: 'Color pickers, palette generators, gradient makers, contrast checkers, and design utilities. All processing runs locally in your browser.' },
  { name: 'Forms & Generators', slug: 'forms', emoji: '&#128221;', trackSlug: 'forms-generators',
    metaDesc: 'Free offline form and generator tools. Form builders, template generators, document creators, and code generators that run locally.',
    heroDesc: 'Form builders, template generators, document creators, code generators, and utility generators. All processing runs locally in your browser.' },
  { name: 'Weather & Climate', slug: 'weather', emoji: '&#9728;', trackSlug: 'weather-climate',
    metaDesc: 'Free offline weather and climate tools. Temperature converters, heat index calculators, wind chill tools, and climate utilities.',
    heroDesc: 'Temperature converters, heat index calculators, wind chill tools, humidity calculators, and climate utilities. All processing runs locally in your browser.' },
  { name: 'Audio & Music Tools', slug: 'audio', emoji: '&#127925;', trackSlug: 'audio-music-tools',
    metaDesc: 'Free offline audio and music tools. Audio converters, BPM detectors, frequency calculators, and music utilities that run locally.',
    heroDesc: 'Audio converters, BPM detectors, frequency calculators, chord finders, and music utilities. All processing runs locally in your browser.' },
  { name: 'Video Tools', slug: 'video', emoji: '&#127916;', trackSlug: 'video-tools',
    metaDesc: 'Free offline video tools. Video format converters, resolution calculators, bitrate tools, and video editing utilities that run locally.',
    heroDesc: 'Video format converters, resolution calculators, bitrate tools, frame extractors, and video utilities. All processing runs locally in your browser.' },
  { name: 'Photography Tools', slug: 'photography', emoji: '&#128247;', trackSlug: 'photography-tools',
    metaDesc: 'Free offline photography tools. EXIF viewers, focal length calculators, exposure tools, and photo utilities that run locally.',
    heroDesc: 'EXIF viewers, focal length calculators, exposure tools, depth of field calculators, and photo utilities. All processing runs locally in your browser.' },
  { name: 'Gaming Tools', slug: 'gaming', emoji: '&#127918;', trackSlug: 'gaming-tools',
    metaDesc: 'Free offline gaming tools. Dice rollers, stat calculators, build planners, and game utilities that run locally in your browser.',
    heroDesc: 'Dice rollers, stat calculators, build planners, sensitivity converters, and gaming utilities. All processing runs locally in your browser.' },
  { name: 'Hobbies & Crafts', slug: 'hobbies', emoji: '&#129522;', trackSlug: 'hobbies-crafts',
    metaDesc: 'Free offline hobby and craft tools. Pattern generators, yarn calculators, craft planners, and hobby utilities that run locally.',
    heroDesc: 'Pattern generators, yarn calculators, craft planners, stitch counters, and hobby utilities. All processing runs locally in your browser.' },
  { name: 'Pets & Animals', slug: 'pets', emoji: '&#128062;', trackSlug: 'pets-animals',
    metaDesc: 'Free offline pet and animal tools. Pet age calculators, feeding guides, dosage calculators, and animal utilities that run locally.',
    heroDesc: 'Pet age calculators, feeding guides, dosage calculators, breeding tools, and animal utilities. All processing runs locally in your browser.' },
  { name: 'Real Estate Tools', slug: 'real-estate', emoji: '&#127968;', trackSlug: 'real-estate-tools',
    metaDesc: 'Free offline real estate tools. Mortgage calculators, property estimators, ROI calculators, and real estate utilities that run locally.',
    heroDesc: 'Mortgage calculators, property estimators, ROI calculators, rental yield tools, and real estate utilities. All processing runs locally in your browser.' },
  { name: 'Religion & Spirituality', slug: 'religion', emoji: '&#128330;', trackSlug: 'religion-spirituality',
    metaDesc: 'Free offline religion and spirituality tools. Prayer time calculators, religious calendars, meditation timers, and spirituality utilities.',
    heroDesc: 'Prayer time calculators, religious calendars, meditation timers, scripture tools, and spirituality utilities. All processing runs locally in your browser.' },
];

// 字面量替换函数（用 split/join，避免正则歧义）
function replaceAll(str, find, rep) {
  return str.split(find).join(rep);
}

let created = 0;
for (const c of cats) {
  let content = template;
  content = replaceAll(content, ORIG.name, c.name);
  content = replaceAll(content, ORIG.trackSlug, c.trackSlug);
  content = replaceAll(content, ORIG.fileName, c.slug + '.html');
  content = replaceAll(content, ORIG.emoji, c.emoji);
  content = replaceAll(content, ORIG.metaDesc, c.metaDesc);
  content = replaceAll(content, ORIG.heroDesc, c.heroDesc);

  const outPath = path.join(root, 'tools', c.slug + '.html');
  fs.writeFileSync(outPath, content, 'utf8');
  created++;
  console.log(`  Created: tools/${c.slug}.html  [${c.name}]`);
}

console.log(`\n=== Done: ${created} pages created ===\n`);

// 列出 tools/ 下所有 html
console.log('=== tools/ 目录 HTML 文件清单 ===');
const files = fs.readdirSync(path.join(root, 'tools'))
  .filter(f => f.endsWith('.html'))
  .sort();
for (const f of files) console.log('  ' + f);
console.log(`\n总计: ${files.length} 个 HTML 文件`);
