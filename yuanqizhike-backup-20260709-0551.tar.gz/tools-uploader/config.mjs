// 本地自动化上传工具配置文件
// 注意：本文件含 API Key，已被 .gitignore 排除，不会进入仓库
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

export default {
  // 本地仪表盘端口
  port: 3000,

  // 路径
  root: ROOT,
  toolsListPath: path.join(ROOT, 'tools-list.json'),
  zipRoot: path.join(ROOT, 'assets', 'zip-packages'),
  iconRoot: path.join(ROOT, 'assets', 'icons'),
  incomingDir: path.join(__dirname, 'incoming'),
  processedDir: path.join(__dirname, 'processed'),

  // AI API（OpenAI 兼容格式）
  ai: {
    apiKey: 'sk-D7Lbtq7t0zTH0qkKJZv6c6wBCafCcenyf0ugNjNv5JhT2Wc1',
    model: 'agnes-2.0-flash',
    baseUrl: 'https://apihub.agnes-ai.com/v1/chat/completions',
    timeoutMs: 30000,
  },

  // 分类 → { iconPrefix, zipFolder }
  // iconPrefix: assets/icons 下图标文件名前缀
  // zipFolder: assets/zip-packages 下存放 zip 的子目录名
  categoryMap: {
    'Content & Writing': { iconPrefix: 'content', zipFolder: 'writing' },
    'Design & Media': { iconPrefix: 'design', zipFolder: 'design' },
    'Developer Tools': { iconPrefix: 'dev', zipFolder: 'dev' },
    'Business & Productivity': { iconPrefix: 'business', zipFolder: 'business' },
    'Education & Research': { iconPrefix: 'education', zipFolder: 'education' },
    'Health & Fitness': { iconPrefix: 'health', zipFolder: 'health' },
    'Finance & Crypto': { iconPrefix: 'finance', zipFolder: 'finance' },
    'SEO & Marketing': { iconPrefix: 'seo', zipFolder: 'seo' },
    'Social Media': { iconPrefix: 'social', zipFolder: 'social' },
    'Lifestyle & Utilities': { iconPrefix: 'lifestyle', zipFolder: 'lifestyle' },
    'Security & Privacy': { iconPrefix: 'security', zipFolder: 'security' },
    'Math & Science': { iconPrefix: 'math', zipFolder: 'math' },
    'AI & ML Utilities': { iconPrefix: 'ai', zipFolder: 'ai' },
    'Travel Tools': { iconPrefix: 'travel', zipFolder: 'travel' },
    'Cooking & Food': { iconPrefix: 'cooking', zipFolder: 'cooking' },
    'Cars & Vehicles': { iconPrefix: 'cars', zipFolder: 'cars' },
    'Color & Design Utilities': { iconPrefix: 'color', zipFolder: 'color' },
    'Forms & Generators': { iconPrefix: 'forms', zipFolder: 'forms' },
    'Weather & Climate': { iconPrefix: 'weather', zipFolder: 'weather' },
    'Audio & Music Tools': { iconPrefix: 'audio', zipFolder: 'audio' },
    'Video Tools': { iconPrefix: 'video', zipFolder: 'video' },
    'Photography Tools': { iconPrefix: 'photography', zipFolder: 'photography' },
    'Gaming Tools': { iconPrefix: 'gaming', zipFolder: 'gaming' },
    'Hobbies & Crafts': { iconPrefix: 'hobbies', zipFolder: 'hobbies' },
    'Pets & Animals': { iconPrefix: 'pets', zipFolder: 'pets' },
    'Real Estate Tools': { iconPrefix: 'real-estate', zipFolder: 'real-estate' },
    'Religion & Spirituality': { iconPrefix: 'religion', zipFolder: 'religion' },
  },

  // AI 识别失败时的回退分类
  fallbackCategory: 'Developer Tools',

  // 单个工具源文件读取到 AI 的最大字符数（token 充裕，扩大以提升识别精准度）
  maxContentChars: 20000,
};
