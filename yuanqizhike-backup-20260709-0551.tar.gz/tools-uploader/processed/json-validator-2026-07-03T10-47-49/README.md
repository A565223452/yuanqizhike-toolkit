# JSON Validator

A free, browser-based JSON validator. Validate syntax and JSON Schema with detailed errors — no installation required.

---

## Features

- Validate JSON syntax
- JSON Schema validation
- Error location
- Auto-fix common errors
- Large file support
- Draft 4/6/7/2019-09

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **API developers**
- **Config authors**
- **Data engineers**
- **QA**
- **Schema designers**

---

## File Structure

```
json-validator/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**