# Import Tariff Calculator

A free, browser-based import tariff calculator. Calculate duties and landed costs for international shipments — no installation required.

---

## Features

- Calculate import duties
- HS code lookup
- Country-specific rates
- Landed cost estimation
- Trade agreement checks
- Multi-item shipments

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Importers**
- **Customs brokers**
- **Supply chain**
- **International trade**
- **E-commerce exporters**

---

## File Structure

```
tariff-calculator/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Business & Productivity CSV Tools**