# SEO Meta Tag Generator

A free, browser-based SEO meta generator. Create complete meta tags for SEO and social — no installation required.

---

## Features

- Title/Description/Keywords
- Open Graph
- Twitter Cards
- Canonical
- Robots
- Viewport
- Charset
- JSON-LD

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **SEO specialists**
- **Web developers**
- **Content managers**
- **Marketers**
- **Site owners**

---

## File Structure

```
seo-meta-generator/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Webmaster Tools**