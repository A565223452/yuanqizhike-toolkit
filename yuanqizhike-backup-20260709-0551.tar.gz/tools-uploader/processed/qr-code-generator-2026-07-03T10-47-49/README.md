# QR Code Generator

A free, browser-based QR code generator. Create QR codes for text, URLs, vCard, WiFi, and more — no installation required.

---

## Features

- Text/URL/vCard/WiFi/Email
- Custom colors/logo
- Error correction
- Batch generate
- SVG/PNG export
- Quiet zone control

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Marketers**
- **Event organizers**
- **Developers**
- **Business cards**
- **Product packaging**

---

## File Structure

```
qr-code-generator/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**