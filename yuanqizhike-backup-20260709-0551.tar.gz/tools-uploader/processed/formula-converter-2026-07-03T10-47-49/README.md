# Formula Converter

A free, browser-based spreadsheet formula converter. Convert Excel/Google Sheets formulas to code — no installation required.

---

## Features

- Excel/Google Sheets to code
- Math.js/JS/Python/SQL
- Cell reference resolution
- Function mapping
- Batch convert
- Custom functions

---

## How to Use

### Step 1: Open the Tool

Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari, etc.).

### Step 2: Use the Tool

Follow the on-screen instructions to use the tool. All processing happens locally in your browser.

---

## Use Cases

- **Analysts**
- **Data scientists**
- **Financial modelers**
- **Developers**
- **Researchers**

---

## File Structure

```
formula-converter/
├── index.html      # Main tool file
└── README.md       # This file
```

---

## Browser Compatibility

Works in all modern browsers that support:

- `FileReader` API
- `Blob` and `URL.createObjectURL`
- ES6+ JavaScript features

Recommended: Chrome 80+, Firefox 75+, Edge 80+, Safari 13+

---

## Privacy

🔒 **100% Private** — All processing happens locally in your browser. No data is sent to any server.

---

## License

Free to use for personal and commercial projects.

**Part of YuanQiZhiLe Toolkit — Developer Free Utility Tools**