// 本地自动化上传主管道
// 启动：node uploader.mjs  （或 npm start）
// 然后浏览器打开 http://localhost:3000
//
// 流程：
//   1. 把工具源文件夹丢进 incoming/
//   2. 页面点"扫描" → 后端读文件夹内容 → 调 AI 拿分类/标题/介绍/features → 选未占用图标 → 生成预览
//   3. 你在页面扫一眼，不对的改一下 → 点"确认入库"
//   4. 后端：打 zip 写到 assets/zip-packages/<分类>/ → 追加 tools-list.json（先备份） → 源文件夹移到 processed/
import http from 'node:http';
import fs from 'node:fs/promises';
import fssync from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';
import cfg from './config.mjs';
import { analyzeTool, selectIcon } from './ai.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const HTML_PATH = path.join(__dirname, 'uploader.html');

const TEXT_EXTS = ['.html', '.htm', '.css', '.js', '.mjs', '.json', '.md', '.txt', '.svg'];
const IGNORE_NAMES = new Set(['.DS_Store', 'Thumbs.db', 'node_modules', '.git', '.idea', '.vscode']);

// ---------- 工具函数 ----------

// 递归列出目录下所有文件（返回 {abs, rel}）
async function walk(dir, base = dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true }).catch(() => []);
  const files = [];
  for (const e of entries) {
    if (IGNORE_NAMES.has(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      files.push(...(await walk(full, base)));
    } else if (e.isFile()) {
      files.push({ abs: full, rel: path.relative(base, full) });
    }
  }
  return files;
}

// 读取文件夹内文本文件内容供 AI 分析（优先级：index.html > 主要 JS > 其它）
// 扩大读取范围：最多 8 个文件，单文件最多 20000 字符（token 充裕）
async function readTextFilesForAI(folderAbs) {
  const files = await walk(folderAbs);
  // 优先级排序：index.html 最先，然后主要 JS 文件，最后其它
  files.sort((a, b) => {
    const score = (f) => {
      const rel = f.rel.toLowerCase();
      if (/index\.html?$/.test(rel)) return 0;
      if (/^(script|app|main|tool|core)\.(js|mjs|ts)$/.test(rel)) return 1;
      if (/\.html?$/.test(rel)) return 2;
      if (/\.(js|mjs|ts)$/.test(rel)) return 3;
      if (/\.css$/.test(rel)) return 4;
      return 5;
    };
    return score(a) - score(b);
  });
  const result = {};
  let count = 0;
  const maxFiles = 8;
  const maxCharsPerFile = 20000;
  for (const f of files) {
    if (count >= maxFiles) break;
    const ext = path.extname(f.rel).toLowerCase();
    if (!TEXT_EXTS.includes(ext)) continue;
    const text = await fs.readFile(f.abs, 'utf8').catch(() => '');
    if (text) {
      const limited = text.length > maxCharsPerFile ? text.slice(0, maxCharsPerFile) + '\n...[truncated]' : text;
      result[f.rel.split(path.sep).join('/')] = limited;
      count++;
    }
  }
  return result;
}

// title → slug
function toSlug(title) {
  return String(title || 'tool')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'tool';
}

// 扫描某分类下可用图标文件名（如 dev-1.svg ... dev-24.svg）
async function listIcons(iconPrefix) {
  const files = await fs.readdir(cfg.iconRoot).catch(() => []);
  const re = new RegExp(`^${iconPrefix}-(\\d+)\\.svg$`);
  return files
    .filter((n) => re.test(n))
    .map((n) => ({ name: n, n: parseInt(n.match(re)[1], 10) }))
    .sort((a, b) => a.n - b.n)
    .map((x) => `/assets/icons/${x.name}`);
}

// 读取 tools-list.json 现有数据
async function loadToolsList() {
  const raw = await fs.readFile(cfg.toolsListPath, 'utf8');
  return JSON.parse(raw);
}

// 生成 zip 到指定路径
async function writeZip(folderAbs, zipPath) {
  const files = await walk(folderAbs);
  const zip = new JSZip();
  for (const f of files) {
    const buf = await fs.readFile(f.abs);
    zip.file(f.rel.split(path.sep).join('/'), buf);
  }
  const buf = await zip.generateAsync({ type: 'nodebuffer' });
  await fs.mkdir(path.dirname(zipPath), { recursive: true });
  await fs.writeFile(zipPath, buf);
}

// 把源文件夹移到 processed/（带时间戳避免覆盖）
async function moveToProcessed(folderAbs) {
  const name = path.basename(folderAbs);
  const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const dest = path.join(cfg.processedDir, `${name}-${ts}`);
  await fs.mkdir(cfg.processedDir, { recursive: true });
  await fs.rename(folderAbs, dest).catch(async () => {
    // 跨盘或失败时复制后删除
    await copyDir(folderAbs, dest);
    await fs.rm(folderAbs, { recursive: true, force: true });
  });
  return dest;
}

async function copyDir(src, dest) {
  await fs.mkdir(dest, { recursive: true });
  const entries = await fs.readdir(src, { withFileTypes: true });
  for (const e of entries) {
    const s = path.join(src, e.name);
    const d = path.join(dest, e.name);
    if (e.isDirectory()) await copyDir(s, d);
    else await fs.copyFile(s, d);
  }
}

// 备份 tools-list.json
async function backupToolsList() {
  try {
    await fs.copyFile(cfg.toolsListPath, cfg.toolsListPath + '.bak');
  } catch (_) {}
}

// ---------- HTTP ----------
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => (data += c));
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

async function handle(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;

  // 首页：操作台
  if (p === '/' && req.method === 'GET') {
    try {
      const html = await fs.readFile(HTML_PATH, 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(html);
    } catch {
      sendJson(res, 500, { error: 'uploader.html 未找到' });
    }
    return;
  }

  // 状态
  if (p === '/api/status' && req.method === 'GET') {
    const list = await loadToolsList().catch(() => []);
    const incoming = await fs.readdir(cfg.incomingDir).catch(() => []);
    const folders = incoming.filter(async (n) => {
      const st = await fs.stat(path.join(cfg.incomingDir, n)).catch(() => null);
      return st && st.isDirectory();
    });
    const realFolders = [];
    for (const n of incoming) {
      const st = await fs.stat(path.join(cfg.incomingDir, n)).catch(() => null);
      if (st && st.isDirectory()) realFolders.push(n);
    }
    sendJson(res, 200, {
      toolsCount: list.length,
      incomingCount: realFolders.length,
      incomingFolders: realFolders,
      zipRoot: cfg.zipRoot,
      toolsListPath: cfg.toolsListPath,
    });
    return;
  }

  // 扫描 incoming（返回待处理文件夹及其文件列表）
  if (p === '/api/scan' && req.method === 'GET') {
    const incoming = await fs.readdir(cfg.incomingDir).catch(() => []);
    const result = [];
    for (const n of incoming) {
      const abs = path.join(cfg.incomingDir, n);
      const st = await fs.stat(abs).catch(() => null);
      if (!st || !st.isDirectory()) continue;
      const files = (await walk(abs)).map((f) => f.rel.split(path.sep).join('/'));
      result.push({ folderName: n, files });
    }
    sendJson(res, 200, { folders: result });
    return;
  }

  // 预览处理：读文件 → 调 AI → 选图标 → 生成预览条目（不写盘）
  if (p === '/api/process' && req.method === 'POST') {
    try {
      const { folders } = await readBody(req);
      const list = await loadToolsList().catch(() => []);
      const usedIcons = new Set(list.map((t) => t.icon).filter(Boolean));
      const usedZipUrls = new Set(list.map((t) => t.zipUrl).filter(Boolean));
      const results = [];
      // 串行处理，避免并发把图标重复分配
      for (const folderName of folders || []) {
        const abs = path.join(cfg.incomingDir, folderName);
        const st = await fs.stat(abs).catch(() => null);
        if (!st || !st.isDirectory()) {
          results.push({ folderName, error: '文件夹不存在' });
          continue;
        }
        const fileContents = await readTextFilesForAI(abs);
        const ai = await analyzeTool({ folderName, fileContents });
        // AI 根据工具用途从该分类图标库里挑最贴合的图标
        const icon = await selectIcon({
          category: ai.category,
          title: ai.title,
          desc: ai.desc,
          features: ai.features,
          usedIcons,
        });
        if (icon) usedIcons.add(icon); // 预占，避免本轮重复
        // slug 用源文件夹名（稳定可重复，保证升级时按 zipUrl 覆盖）
        let slug = toSlug(folderName);
        let zipUrl = `/assets/zip-packages/${cfg.categoryMap[ai.category].zipFolder}/${slug}.zip`;
        // 检测是否为覆盖模式（tools-list.json 已存在同名 zipUrl）
        const isUpgrade = usedZipUrls.has(zipUrl);
        usedZipUrls.add(zipUrl);
        results.push({
          folderName,
          category: ai.category,
          title: ai.title,
          desc: ai.desc,
          features: ai.features,
          icon,
          zipUrl,
          detailUrl: '',
          aiOk: ai.aiOk,
          aiError: ai.aiError || null,
          isUpgrade,
        });
      }
      sendJson(res, 200, { items: results });
    } catch (e) {
      sendJson(res, 500, { error: String(e.message || e) });
    }
    return;
  }

  // 确认入库：打 zip + 追加 tools-list.json + 移动源文件夹
  if (p === '/api/commit' && req.method === 'POST') {
    try {
      const { items } = await readBody(req);
      if (!Array.isArray(items) || items.length === 0) {
        sendJson(res, 400, { error: 'items 为空' });
        return;
      }
      await backupToolsList();
      const list = await loadToolsList();
      const report = [];
      for (const item of items) {
        const folderAbs = path.join(cfg.incomingDir, item.folderName);
        const st = await fs.stat(folderAbs).catch(() => null);
        if (!st || !st.isDirectory()) {
          report.push({ folderName: item.folderName, ok: false, error: '源文件夹不存在' });
          continue;
        }
        // 校验分类合法
        const map = cfg.categoryMap[item.category];
        if (!map) {
          report.push({ folderName: item.folderName, ok: false, error: '分类非法' });
          continue;
        }
        // 打 zip 写盘
        const zipAbs = path.join(cfg.root, item.zipUrl);
        await writeZip(folderAbs, zipAbs);
        // 覆盖或新增：按 zipUrl 查重，存在则更新（含 title/desc/features/icon），不存在则追加
        const entry = {
          category: item.category,
          icon: item.icon,
          title: item.title,
          desc: item.desc,
          features: item.features || [],
          detailUrl: item.detailUrl || '',
          zipUrl: item.zipUrl,
        };
        const existingIdx = list.findIndex(t => t.zipUrl === item.zipUrl);
        if (existingIdx >= 0) {
          list[existingIdx] = entry;  // 覆盖更新 metadata
        } else {
          list.push(entry);  // 新增
        }
        // 源文件夹归档
        await moveToProcessed(folderAbs);
        report.push({ folderName: item.folderName, ok: true, zipUrl: item.zipUrl, isUpgrade: existingIdx >= 0 });
      }
      // 写回 tools-list.json
      await fs.writeFile(cfg.toolsListPath, JSON.stringify(list, null, 2) + '\n', 'utf8');
      sendJson(res, 200, { report, toolsCount: list.length });
    } catch (e) {
      sendJson(res, 500, { error: String(e.message || e) });
    }
    return;
  }

  // 图标列表（某分类）
  if (p === '/api/icons' && req.method === 'GET') {
    const category = url.searchParams.get('category');
    const map = cfg.categoryMap[category];
    if (!map) {
      sendJson(res, 400, { error: '分类非法' });
      return;
    }
    const icons = await listIcons(map.iconPrefix);
    sendJson(res, 200, { icons });
    return;
  }

  sendJson(res, 404, { error: 'Not Found: ' + p });
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((e) => {
    sendJson(res, 500, { error: String(e?.message || e) });
  });
});

// 确保工作目录存在
await fs.mkdir(cfg.incomingDir, { recursive: true });
await fs.mkdir(cfg.processedDir, { recursive: true });

server.listen(cfg.port, () => {
  console.log('==========================================');
  console.log(' YuanqiZhiKe 自动化上传工具已启动');
  console.log('==========================================');
  console.log(` 操作台:  http://localhost:${cfg.port}`);
  console.log(` 投放目录: ${cfg.incomingDir}`);
  console.log(` 归档目录: ${cfg.processedDir}`);
  console.log(` 数据文件: ${cfg.toolsListPath}`);
  console.log(` ZIP 目录: ${cfg.zipRoot}`);
  console.log('------------------------------------------');
  console.log(' 用法: 把工具源文件夹丢进 incoming/ ，');
  console.log('       浏览器打开操作台点"扫描"即可。');
  console.log('==========================================');
});
