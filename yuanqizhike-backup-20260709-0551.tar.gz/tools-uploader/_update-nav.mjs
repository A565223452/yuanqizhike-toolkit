// 统一更新所有 tools/*.html 的导航下拉菜单为完整 27 项分类
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const toolsDir = path.join(root, 'tools');

// 27 个分类定义（顺序固定）
const categories = [
  { name: 'Content & Writing', file: 'writing.html' },
  { name: 'Design & Media', file: 'design.html' },
  { name: 'Developer Tools', file: 'dev.html' },
  { name: 'Business & Productivity', file: 'business.html' },
  { name: 'Education & Research', file: 'research.html' },
  { name: 'Health & Fitness', file: 'health.html' },
  { name: 'Finance & Crypto', file: 'finance.html' },
  { name: 'SEO & Marketing', file: 'seo.html' },
  { name: 'Social Media', file: 'social.html' },
  { name: 'Lifestyle & Utilities', file: 'lifestyle.html' },
  { name: 'Security & Privacy', file: 'security.html' },
  { name: 'Math & Science', file: 'math.html' },
  { name: 'AI & ML Utilities', file: 'ai.html' },
  { name: 'Travel Tools', file: 'travel.html' },
  { name: 'Cooking & Food', file: 'cooking.html' },
  { name: 'Cars & Vehicles', file: 'cars.html' },
  { name: 'Color & Design Utilities', file: 'color.html' },
  { name: 'Forms & Generators', file: 'forms.html' },
  { name: 'Weather & Climate', file: 'weather.html' },
  { name: 'Audio & Music Tools', file: 'audio.html' },
  { name: 'Video Tools', file: 'video.html' },
  { name: 'Photography Tools', file: 'photography.html' },
  { name: 'Gaming Tools', file: 'gaming.html' },
  { name: 'Hobbies & Crafts', file: 'hobbies.html' },
  { name: 'Pets & Animals', file: 'pets.html' },
  { name: 'Real Estate Tools', file: 'real-estate.html' },
  { name: 'Religion & Spirituality', file: 'religion.html' },
];

// 读取所有 tools/*.html
const files = fs.readdirSync(toolsDir).filter(f => f.endsWith('.html'));
let updated = 0;

for (const file of files) {
  const filePath = path.join(toolsDir, file);
  let content = fs.readFileSync(filePath, 'utf8');

  // 生成新的 dropdown-menu 内容
  // 第一项固定是 All Tools (../tools.html)，然后 27 个分类
  const lines = ['                        <a href="../tools.html">All Tools</a>'];
  for (const c of categories) {
    const active = c.file === file ? ' class="active"' : '';
    lines.push(`                        <a href="${c.file}"${active}>${c.name}</a>`);
  }
  const newMenu = '                    <div class="dropdown-menu">\n' + lines.join('\n') + '\n                    </div>';

  // 替换原 dropdown-menu 块（非贪婪匹配到第一个 </div>）
  const regex = /<div class="dropdown-menu">[\s\S]*?<\/div>/;
  const match = content.match(regex);
  if (!match) {
    console.log(`  SKIP: ${file} (dropdown-menu not found)`);
    continue;
  }

  const oldMenu = match[0];
  if (oldMenu === newMenu) {
    console.log(`  OK:   ${file} (already up to date)`);
    continue;
  }

  content = content.replace(regex, newMenu);
  fs.writeFileSync(filePath, content, 'utf8');
  updated++;
  console.log(`  Updated: ${file}`);
}

console.log(`\n=== Done: ${updated} files updated ===`);

// 验证：检查每个文件的导航项数量
console.log('\n=== 验证：各文件导航项数量 ===');
for (const file of files) {
  const content = fs.readFileSync(path.join(toolsDir, file), 'utf8');
  const menuMatch = content.match(/<div class="dropdown-menu">[\s\S]*?<\/div>/);
  if (menuMatch) {
    const linkCount = (menuMatch[0].match(/<a /g) || []).length;
    const hasActive = /class="active"/.test(menuMatch[0]);
    console.log(`  ${file}: ${linkCount} links, active=${hasActive}`);
  }
}
