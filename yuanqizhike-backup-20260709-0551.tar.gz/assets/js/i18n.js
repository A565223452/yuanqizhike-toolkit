// ===================================
// YuanqiZhiKe Toolkit - Internationalization (i18n)
// ===================================

const I18N = {
  currentLang: 'en',
  translations: {},
  supportedLangs: [
    { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸' },
    { code: 'zh', name: 'Chinese', nativeName: '中文', flag: '🇨🇳' },
    { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
    { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵' }
  ],

  // Initialize i18n system
  async init() {
    // Get language from URL param, localStorage, or browser
    const urlParams = new URLSearchParams(window.location.search);
    const langFromUrl = urlParams.get('lang');
    const langFromStorage = localStorage.getItem('yuanqi_lang');
    const browserLang = this.detectBrowserLanguage();

    this.currentLang = langFromUrl || langFromStorage || browserLang || 'en';
    
    // Load translations
    await this.loadTranslations(this.currentLang);
    
    // Apply translations to page
    this.applyTranslations();
    
    // Update language switcher UI
    this.updateLanguageSwitcher();
    
    // Update HTML lang attribute
    document.documentElement.lang = this.currentLang;
    
    // Update SEO meta tags
    this.updateMetaTags();
    
    // Update Giscus language
    this.updateGiscusLang();
    
    // Listen for language changes
    this.setupLangChangeHandler();
  },

  // Detect browser language
  detectBrowserLanguage() {
    const browserLang = (navigator.language || navigator.userLanguage || '').toLowerCase();
    if (browserLang.startsWith('zh')) return 'zh';
    if (browserLang.startsWith('es')) return 'es';
    if (browserLang.startsWith('ja')) return 'ja';
    return 'en';
  },

  // Load translations for a language
  async loadTranslations(lang) {
    try {
      const response = await fetch(`locales/${lang}.json`);
      if (response.ok) {
        this.translations[lang] = await response.json();
      } else {
        // Fallback to English
        console.warn(`Failed to load ${lang} translations, using English fallback.`);
        const enResponse = await fetch('locales/en.json');
        this.translations[lang] = enResponse.ok ? await enResponse.json() : {};
        this.currentLang = 'en';
      }
    } catch (error) {
      console.error('Error loading translations:', error);
      this.translations[lang] = {};
    }
  },

  // Get translated string
  t(key, fallback) {
    const keys = key.split('.');
    let value = this.translations[this.currentLang];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return fallback || key;
      }
    }
    
    return typeof value === 'string' ? value : fallback || key;
  },

  // Apply translations to all elements with data-i18n attribute
  applyTranslations() {
    // Translate elements with data-i18n attribute
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      const text = this.t(key);
      if (el.tagName === 'TITLE') {
        document.title = text;
      } else if (el.tagName === 'META') {
        // Handle meta tags
        const attr = el.getAttribute('data-i18n-attr');
        if (attr) el.setAttribute(attr, text);
        else el.textContent = text;
      } else {
        el.textContent = text;
      }
    });

    // Translate elements with data-i18n-placeholder
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      el.placeholder = this.t(key);
    });

    // Translate elements with data-i18n-title (tooltip)
    document.querySelectorAll('[data-i18n-title]').forEach(el => {
      const key = el.getAttribute('data-i18n-title');
      el.title = this.t(key);
    });

    // Translate h1-h6 with data-i18n-keys (comma-separated)
    document.querySelectorAll('[data-i18n-keys]').forEach(el => {
      const keys = el.getAttribute('data-i18n-keys').split(',');
      const texts = keys.map(k => this.t(k.trim()));
      if (texts.length === 1) {
        el.textContent = texts[0];
      } else {
        // For multi-part headings, keep as is but update text
        el.innerHTML = texts.join('');
      }
    });

    // Translate description paragraphs
    document.querySelectorAll('[data-i18n-desc]').forEach(el => {
      const key = el.getAttribute('data-i18n-desc');
      el.textContent = this.t(key);
    });
  },

  // Update language switcher dropdown
  updateLanguageSwitcher() {
    const switcher = document.getElementById('languageSwitcher');
    const dropdown = document.getElementById('languageDropdown');
    
    if (!switcher || !dropdown) return;

    // Update button display
    const currentLang = this.supportedLangs.find(l => l.code === this.currentLang);
    if (currentLang) {
      switcher.innerHTML = `${currentLang.flag} ${currentLang.nativeName}`;
    }

    // Build dropdown menu
    dropdown.innerHTML = this.supportedLangs.map(lang => `
      <a href="#" class="lang-option" data-lang="${lang.code}" onclick="I18N.switchTo('${lang.code}'); return false;">
        <span class="lang-flag">${lang.flag}</span>
        <span class="lang-name">${lang.nativeName}</span>
        ${lang.code === this.currentLang ? '<span class="lang-current">✓</span>' : ''}
      </a>
    `).join('');
  },

  // Switch to a different language
  async switchTo(lang) {
    if (!this.supportedLangs.find(l => l.code === lang)) return;
    
    this.currentLang = lang;
    localStorage.setItem('yuanqi_lang', lang);
    
    // Update URL without page reload
    const url = new URL(window.location);
    url.searchParams.set('lang', lang);
    window.history.pushState({}, '', url);
    
    // Load and apply translations
    await this.loadTranslations(lang);
    this.applyTranslations();
    this.updateLanguageSwitcher();
    document.documentElement.lang = lang;
    this.updateMetaTags();
    this.updateGiscusLang();
    
    // Close dropdown
    const dropdown = document.getElementById('languageDropdown');
    if (dropdown) dropdown.classList.remove('open');
  },

  // Setup language change URL handler
  setupLangChangeHandler() {
    // Handle back/forward navigation
    window.addEventListener('popstate', () => {
      const urlParams = new URLSearchParams(window.location.search);
      const lang = urlParams.get('lang') || this.currentLang;
      this.switchTo(lang);
    });
  },

  // Update meta tags for SEO
  updateMetaTags() {
    const t = this.t.bind(this);
    
    // Update title
    const titleKey = 'hero.title';
    document.title = `${t(titleKey)} - YuanqiZhiKe Toolkit`;

    // Update description
    const descEl = document.querySelector('meta[name="description"]');
    if (descEl) {
      descEl.content = t('hero.description');
    }

    // Update OG tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.content = document.title;
    
    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) ogDesc.content = t('hero.description');

    // Update hreflang links
    this.updateHreflangs();
  },

  // Update hreflang tags for multi-language SEO
  updateHreflangs() {
    // Remove existing hreflang links
    document.querySelectorAll('link[hreflang]').forEach(el => el.remove());

    // Add new hreflang links
    const baseUrl = window.location.origin + window.location.pathname;
    this.supportedLangs.forEach(lang => {
      const link = document.createElement('link');
      link.rel = 'alternate';
      link.hreflang = lang.code;
      link.href = `${baseUrl}?lang=${lang.code}`;
      document.head.appendChild(link);
    });

    // Add x-default
    const defaultLink = document.createElement('link');
    defaultLink.rel = 'alternate';
    defaultLink.hreflang = 'x-default';
    defaultLink.href = baseUrl;
    document.head.appendChild(defaultLink);
  },

  // Update Giscus comment section language
  updateGiscusLang() {
    const giscusFrame = document.querySelector('giscus-widget');
    if (giscusFrame) {
      // Map our langs to Giscus supported langs
      const langMap = {
        'en': 'en',
        'zh': 'zh-CN',
        'es': 'es',
        'ja': 'ja'
      };
      
      const giscusLang = langMap[this.currentLang] || 'en';
      
      // Send message to update Giscus language
      if (giscusFrame.shadowRoot) {
        const iframe = giscusFrame.shadowRoot.querySelector('iframe');
        if (iframe) {
          iframe.contentWindow.postMessage({ 
            giscus: { setConfig: { lang: giscusLang } } 
          }, 'https://giscus.app');
        }
      }
    }
  }
};

// Make I18N globally accessible
window.I18N = I18N;

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  I18N.init().catch(console.error);
});