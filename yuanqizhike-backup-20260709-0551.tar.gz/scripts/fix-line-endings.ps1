$content = Get-Content functions/api/send-email.js -Raw
$content = $content -replace "`r`n", "`n"
[System.IO.File]::WriteAllText('functions/api/send-email.js', $content, [System.Text.UTF8Encoding]::new($false))
Write-Host "Line endings converted to LF, BOM removed"
