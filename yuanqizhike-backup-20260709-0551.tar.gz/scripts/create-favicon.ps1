$svgContent = '<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <rect width="64" height="64" rx="8" fill="#2563eb"/>
  <text x="32" y="44" font-size="40" font-family="Arial" font-weight="bold" fill="white" text-anchor="middle">Y</text>
</svg>'

[System.IO.File]::WriteAllText((Join-Path $PWD 'favicon.svg'), $svgContent, [System.Text.Encoding]::UTF8)
Write-Host "favicon.svg created successfully!"