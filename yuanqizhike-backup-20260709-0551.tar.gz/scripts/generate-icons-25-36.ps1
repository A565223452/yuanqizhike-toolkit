# Generate SVG icons 25-36 for all categories
$categories = @("content", "design", "dev", "business", "education")
$iconsDir = "assets/icons"

foreach ($cat in $categories) {
    for ($i = 25; $i -le 36; $i++) {
        $svgContent = @"
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <rect x="3" y="3" width="18" height="18" rx="2" fill="#${cat}"/>
  <text x="12" y="16" text-anchor="middle" font-size="10" fill="#${cat}" stroke="none">${i}</text>
</svg>
"@
        $filePath = Join-Path $iconsDir "${cat}-${i}.svg"
        Set-Content -Path $filePath -Value $svgContent -Encoding UTF8
        Write-Host "Created: $filePath"
    }
}

Write-Host "`nAll icons 25-36 generated for all categories!"