# 批量创建 SVG 图标脚本
# 运行方式: powershell -ExecutionPolicy Bypass -File scripts\create-icons.ps1

$basePath = "assets/icons"

# 确保目录存在
if (-not (Test-Path $basePath)) {
    New-Item -ItemType Directory -Path $basePath | Out-Null
}

# Content & Writing 图标
@{
    'assets/icons/content-1.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="10" y="6" width="44" height="52" rx="3" fill="none" stroke="#2563eb" stroke-width="2.5"/><line x1="18" y1="18" x2="46" y2="18" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/><line x1="18" y1="26" x2="46" y2="26" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/><line x1="18" y1="34" x2="38" y2="34" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/></svg>'
    'assets/icons/content-2.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M12 8 L52 8 L52 56 L12 56 Z" fill="none" stroke="#2563eb" stroke-width="2.5"/><path d="M20 8 L20 56" stroke="#2563eb" stroke-width="1"/><text x="36" y="24" font-size="10" fill="#2563eb" font-family="Arial">Aa</text></svg>'
    'assets/icons/content-3.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="12" y="4" width="40" height="56" rx="4" fill="none" stroke="#2563eb" stroke-width="2.5"/><path d="M20 20 L44 20 M20 28 L44 28 M20 36 L36 36 M20 44 L40 44" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/></svg>'
} | Get-HashTable | ForEach-Object {
    param($pair)
    [System.IO.File]::WriteAllText($pair.Key, $pair.Value, [System.Text.Encoding]::UTF8)
    Write-Host ("Created: " + $pair.Key)
}

# Design & Media 图标
@{
    'assets/icons/design-1.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="22" fill="none" stroke="#2563eb" stroke-width="2.5"/><circle cx="24" cy="26" r="4" fill="#ef4444"/><circle cx="40" cy="26" r="4" fill="#22c55e"/><circle cx="32" cy="40" r="4" fill="#3b82f6"/></svg>'
    'assets/icons/design-2.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="8" y="8" width="48" height="48" rx="6" fill="none" stroke="#2563eb" stroke-width="2.5"/><polygon points="20,44 28,20 36,36 44,28" fill="none" stroke="#2563eb" stroke-width="2" stroke-linejoin="round"/></svg>'
    'assets/icons/design-3.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="24" fill="none" stroke="#2563eb" stroke-width="2.5"/><circle cx="24" cy="28" r="6" fill="#f59e0b" opacity="0.6"/><circle cx="40" cy="28" r="6" fill="#8b5cf6" opacity="0.6"/><circle cx="32" cy="40" r="6" fill="#06b6d4" opacity="0.6"/></svg>'
} | ForEach-Object {
    $_.GetEnumerator() | ForEach-Object {
        [System.IO.File]::WriteAllText($_.Key, $_.Value, [System.Text.Encoding]::UTF8)
        Write-Host ("Created: " + $_.Key)
    }
}

# Developer Tools 图标
@{
    'assets/icons/dev-1.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="6" y="12" width="52" height="36" rx="4" fill="none" stroke="#2563eb" stroke-width="2.5"/><line x1="6" y1="20" x2="58" y2="20" stroke="#2563eb" stroke-width="1.5"/><circle cx="12" cy="16" r="2" fill="#ef4444"/><circle cx="18" cy="16" r="2" fill="#eab308"/><circle cx="24" cy="16" r="2" fill="#22c55e"/><text x="14" y="36" font-size="11" fill="#2563eb" font-family="monospace">LT/GT</text></svg>'
    'assets/icons/dev-2.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><polyline points="16,20 8,32 16,44" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><polyline points="48,20 56,32 48,44" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="38" y1="24" x2="26" y2="40" stroke="#2563eb" stroke-width="2.5" stroke-linecap="round"/></svg>'
    'assets/icons/dev-3.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="10" y="10" width="44" height="44" rx="6" fill="none" stroke="#2563eb" stroke-width="2.5"/><line x1="20" y1="24" x2="44" y2="24" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/><line x1="20" y1="32" x2="38" y2="32" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/><line x1="20" y1="40" x2="42" y2="40" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/></svg>'
} | ForEach-Object {
    $_.GetEnumerator() | ForEach-Object {
        [System.IO.File]::WriteAllText($_.Key, $_.Value, [System.Text.Encoding]::UTF8)
        Write-Host ("Created: " + $_.Key)
    }
}

# Business & Productivity 图标
@{
    'assets/icons/business-1.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="10" y="14" width="44" height="36" rx="3" fill="none" stroke="#2563eb" stroke-width="2.5"/><line x1="10" y1="24" x2="54" y2="24" stroke="#2563eb" stroke-width="1.5"/><rect x="16" y="30" width="12" height="4" rx="1" fill="#2563eb"/><rect x="16" y="38" width="20" height="4" rx="1" fill="#94a3b8"/><rect x="16" y="46" width="16" height="4" rx="1" fill="#94a3b8"/></svg>'
    'assets/icons/business-2.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="24" fill="none" stroke="#2563eb" stroke-width="2.5"/><path d="M32 16 L32 32 L42 38" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
    'assets/icons/business-3.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="8" y="16" width="48" height="32" rx="4" fill="none" stroke="#2563eb" stroke-width="2.5"/><rect x="14" y="22" width="8" height="6" rx="1" fill="#2563eb"/><rect x="26" y="22" width="8" height="6" rx="1" fill="#94a3b8"/><rect x="38" y="22" width="8" height="6" rx="1" fill="#94a3b8"/><rect x="14" y="34" width="36" height="4" rx="1" fill="#94a3b8"/></svg>'
} | ForEach-Object {
    $_.GetEnumerator() | ForEach-Object {
        [System.IO.File]::WriteAllText($_.Key, $_.Value, [System.Text.Encoding]::UTF8)
        Write-Host ("Created: " + $_.Key)
    }
}

# Education & Research 图标
@{
    'assets/icons/education-1.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M32 8 L56 22 L32 36 L8 22 Z" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linejoin="round"/><line x1="32" y1="36" x2="32" y2="56" stroke="#2563eb" stroke-width="2.5"/><path d="M16 44 L32 56 L48 44" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linejoin="round"/></svg>'
    'assets/icons/education-2.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="8" y="16" width="48" height="36" rx="3" fill="none" stroke="#2563eb" stroke-width="2.5"/><line x1="16" y1="26" x2="48" y2="26" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/><line x1="16" y1="34" x2="40" y2="34" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/><line x1="16" y1="42" x2="44" y2="42" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/></svg>'
    'assets/icons/education-3.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M12 16 L52 16 L52 48 L12 48 Z" fill="none" stroke="#2563eb" stroke-width="2.5"/><path d="M12 16 L24 28 L12 40" fill="none" stroke="#2563eb" stroke-width="2" stroke-linejoin="round"/><circle cx="38" cy="32" r="6" fill="none" stroke="#2563eb" stroke-width="2"/></svg>'
} | ForEach-Object {
    $_.GetEnumerator() | ForEach-Object {
        [System.IO.File]::WriteAllText($_.Key, $_.Value, [System.Text.Encoding]::UTF8)
        Write-Host ("Created: " + $_.Key)
    }
}

Write-Host "`nAll icons created!" -ForegroundColor Green
