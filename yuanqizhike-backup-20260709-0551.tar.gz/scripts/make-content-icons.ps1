$icons = @{
    'assets/icons/content-1.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="10" y="6" width="44" height="52" rx="3" fill="none" stroke="#2563eb" stroke-width="2.5"/><line x1="18" y1="18" x2="46" y2="18" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/><line x1="18" y1="26" x2="46" y2="26" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/><line x1="18" y1="34" x2="38" y2="34" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/></svg>'
    'assets/icons/content-2.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M12 8 L52 8 L52 56 L12 56 Z" fill="none" stroke="#2563eb" stroke-width="2.5"/><path d="M20 8 L20 56" stroke="#2563eb" stroke-width="1"/><text x="36" y="24" font-size="10" fill="#2563eb" font-family="Arial">Aa</text></svg>'
    'assets/icons/content-3.svg' = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="12" y="4" width="40" height="56" rx="4" fill="none" stroke="#2563eb" stroke-width="2.5"/><path d="M20 20 L44 20 M20 28 L44 28 M20 36 L36 36 M20 44 L40 44" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/></svg>'
}

foreach ($key in $icons.Keys) {
    [System.IO.File]::WriteAllText($key, $icons[$key], [System.Text.Encoding]::UTF8)
    Write-Host ("Created: " + $key)
}

Write-Host "`nContent icons created!" -ForegroundColor Green